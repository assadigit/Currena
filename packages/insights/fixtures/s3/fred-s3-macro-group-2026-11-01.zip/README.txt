----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-31 7:27 pm CDT
----------------------------------------------------------------

-------------------  ---------------------------------------------------------------------  ------------------------
GDPNOW               GDPNow, Percent Change at Annual Rate, Quarterly, Seasonally Adjusted  Data Updated: 2026-10-29
                     Annual Rate
GACDISA066MSFRBNY    Current General Business Conditions; Diffusion Index for New York,     Data Updated: 2026-10-15
                     Index, Monthly, Seasonally Adjusted
MEDCPIM158SFRBCLE    Median Consumer Price Index, Percent Change at Annual Rate, Monthly,   Data Updated: 2026-10-14
                     Seasonally Adjusted
STICKCPIM158SFRBATL  Sticky Price Consumer Price Index, Percent Change at Annual Rate,      Data Updated: 2026-10-14
                     Monthly, Seasonally Adjusted
MTSDS133FMS          Federal Surplus or Deficit [-], Millions of Dollars, Monthly, Not      Data Updated: 2026-10-16
                     Seasonally Adjusted
DRTSCILM             Net Percentage of Domestic Banks Tightening Standards for Commercial   Data Updated: 2026-08-03
                     and Industrial Loans to Large and Middle-Market Firms, Percent,
                     Quarterly, Not Seasonally Adjusted
-------------------  ---------------------------------------------------------------------  ------------------------

