----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-31 7:27 pm CDT
----------------------------------------------------------------

-----------  ----------------------------------------------------------------------  ------------------------
THREEFYTP10  Term Premium on a 10 Year Zero Coupon Bond, Percent, Daily, Not         Data Updated: 2026-10-27
             Seasonally Adjusted
WTREGEN      Liabilities and Capital: Liabilities: Deposits with F.R. Banks, Other   Data Updated: 2026-10-29
             Than Reserve Balances: U.S. Treasury, General Account: Week Average,
             Millions of U.S. Dollars, Weekly, Not Seasonally Adjusted
RRPONTSYD    Overnight Reverse Repurchase Agreements: Treasury Securities Sold by    Data Updated: 2026-10-30
             the Federal Reserve in the Temporary Open Market Operations, Billions
             of US Dollars, Daily, Not Seasonally Adjusted
WRESBAL      Liabilities and Capital: Other Factors Draining Reserve Balances:       Data Updated: 2026-10-29
             Reserve Balances with Federal Reserve Banks: Week Average, Millions of
             U.S. Dollars, Weekly, Not Seasonally Adjusted
IORB         Interest Rate on Reserve Balances (IORB Rate), Percent, Daily, Not      Data Updated: 2026-10-30
             Seasonally Adjusted
CCSA         Continued Claims (Insured Unemployment), Number, Weekly, Seasonally     Data Updated: 2026-10-29
             Adjusted
-----------  ----------------------------------------------------------------------  ------------------------

