# 06 — Acceptance Criteria and Test Plan

Mark an item complete only after it is demonstrated in the actual application or through an appropriate automated test. Report blocked checks honestly.

## 1. Repository discovery gate

- [ ] The agent identifies the framework, build tools, styling system, localization approach, responsive conventions, and current test commands from the repository.
- [ ] The existing asset-card component and all data sources are located.
- [ ] The existing meaning/calculation of the «بالا» status label is traced.
- [ ] Current price units, benchmark identifiers, price timestamps, return horizons, and 52-week calculations are documented.
- [ ] The audit identifies any user-configurable asset order or state behavior that must be preserved.
- [ ] The implementation plan lists intended files and regression risks before code changes.
- [ ] No technology, API, data source, or score is assumed without evidence from the repository.

## 2. Visual hierarchy

- [ ] Each card clearly identifies the asset before secondary metadata.
- [ ] The current price is the dominant numeric element.
- [ ] The unit is grouped with the price but visually subordinate.
- [ ] The unit does not look more important than the asset title.
- [ ] The seven-day movement is the primary trend story.
- [ ] Daily change is clearly labelled and secondary.
- [ ] Freshness is visible without dominating the card.
- [ ] Briefing copy is concise and not duplicated by multiple statistics.
- [ ] Card icons, typography, spacing, alignment, and borders are consistent.
- [ ] Long titles and descriptions do not collide or clip.

## 3. Trend and sparkline integrity

- [ ] The sparkline uses real observations for the correct asset, instrument, currency, and unit.
- [ ] Its timeframe is explicitly labelled as the past seven days (with the actual rolling/calendar convention documented).
- [ ] The chart and its accompanying text use compatible time boundaries.
- [ ] Invalid values, duplicate timestamps, and missing intervals are handled safely.
- [ ] Missing history never produces an invented flat line or synthetic chart.
- [ ] A partially missing series is identified as incomplete where material.
- [ ] The trend label comes from documented existing logic or a reviewed, tested method.
- [ ] If no validated trend method exists, the card does not invent a categorical badge.
- [ ] A daily move is not incorrectly substituted for a seven-day trend.
- [ ] The chart is not used to imply future direction or confidence.
- [ ] Price-only data does not produce unsupported causal explanations.

## 4. Financial UX writing

- [ ] Default summary is usually one or two concise sentences.
- [ ] Statements about observed movement identify the period.
- [ ] Interpretations are appropriately hedged.
- [ ] Causal language is used only when supporting evidence is available.
- [ ] No unsupported forecast, probability, buy/sell signal, or certainty claim is displayed.
- [ ] Bitcoin wording is cautious and does not infer persistence from one short move.
- [ ] “No clear direction,” stale data, insufficient evidence, and unavailable data are distinguishable.
- [ ] Persian and English copy are complete, natural, and consistent with actual model semantics.

## 5. Expanded details

- [ ] Existing useful weekly/monthly/annual changes and historical statistics remain accessible.
- [ ] Details open and close with keyboard and pointer/touch input.
- [ ] Expanded state is exposed accessibly.
- [ ] Details do not shift focus unexpectedly.
- [ ] The main card remains concise after the change.
- [ ] Per-card disclosure behavior follows existing product conventions.

## 6. Responsive verification

Test at minimum:
- 320 CSS px;
- 375–390 CSS px;
- a common tablet width around 768 px;
- common desktop widths around 1280–1440 px;
- a wide desktop layout.

Acceptance:
- [ ] No horizontal page overflow at 320 CSS px.
- [ ] The mobile view uses an appropriate stacked/adaptive layout.
- [ ] Tablet columns are retained only when card content stays readable.
- [ ] Persian text and long English asset names wrap correctly.
- [ ] Price and unit remain visually grouped.
- [ ] Expanded details remain usable at all supported widths.
- [ ] Browser zoom/text scaling does not hide controls or data.
- [ ] The layout remains stable when one card's text is longer than others.

## 7. RTL/LTR and accessibility

- [ ] Persian RTL and English LTR both pass visual inspection.
- [ ] Signs, values, dates, unit strings, and Latin codes appear in the correct order.
- [ ] No direction state depends on color alone.
- [ ] Keyboard focus is visible.
- [ ] Disclosure states are announced correctly by assistive technology.
- [ ] Chart has an accessible equivalent or is correctly marked decorative.
- [ ] Color contrast meets applicable accessibility targets.
- [ ] Reduced-motion preference is respected where motion exists.

## 8. Data/error cases

Test:
- [ ] Fully valid latest price and seven-day history.
- [ ] Price available, seven-day history unavailable.
- [ ] Sparse/partial history.
- [ ] Stale quote.
- [ ] Fetch failure with no cache.
- [ ] Fetch failure with cached old data.
- [ ] Invalid/non-finite price.
- [ ] Missing unit or instrument metadata.
- [ ] Conflicting daily and seven-day directions.
- [ ] One asset fails while other cards succeed.
- [ ] Expanded details fail independently.

## 9. Regression and implementation

- [ ] Only in-scope card behavior and necessary supporting code are changed.
- [ ] Page header, routing, unrelated sections, and existing capabilities are preserved.
- [ ] No market-data provider is replaced without approval.
- [ ] No dependency is added without documented justification.
- [ ] Relevant tests, lint, type-check, and build pass where available.
- [ ] Screenshot checks cover Persian RTL and English LTR at mobile and desktop widths where tooling permits.
- [ ] Any unrun checks and known limitations are reported.

## 10. Required final handoff

The coding agent must report:
1. What changed and why.
2. Exact files changed.
3. How the «بالا» label was handled and why.
4. How the seven-day sparkline is sourced and how its window is defined.
5. How the briefing avoids unsupported causal/forecast statements.
6. Responsive and localization decisions.
7. Tests run and results.
8. Before/after screenshots if available.
9. Remaining risks, missing data, or deferred work.
