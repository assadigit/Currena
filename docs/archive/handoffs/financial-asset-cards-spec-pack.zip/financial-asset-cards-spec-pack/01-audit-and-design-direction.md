# 01 — UI/UX Audit and Design Direction

## 1. Product goal

Each card should act as a small, credible market briefing—not a miniature financial report.

Within a few seconds, the user should be able to identify:
1. Which asset they are looking at.
2. Its current/latest price and price unit.
3. The shape and direction of its recent seven-day movement, where the data supports such a description.
4. The latest daily change as a secondary detail.
5. A short, careful interpretation grounded in available evidence.
6. When the displayed data was last updated.
7. Where to find additional statistics without crowding the default card.

The page's outer heading and other sections are outside this redesign's scope.

## 2. Existing UI audit based on the supplied screenshot

### What is working
- The repeated card pattern makes the assets easy to compare.
- Clear asset icons support quick recognition.
- The restrained background, borders, and navy typography suit a financial product.
- Displaying multiple time horizons and 52-week context can be valuable.
- Existing explanatory text shows the product is aiming to interpret data, not just print prices.

### What is not working well
1. **The typographic hierarchy is weak.** The title and unit can compete, and the title may visually appear less important than the unit. The asset title should identify the card; the price should be the dominant numeric element; the unit is secondary metadata adjacent to the price.
2. **Too much information is shown by default.** Several return periods, historical records, multiple explanatory paragraphs, and extra statistics make each card feel like a condensed report.
3. **Text density differs significantly by asset.** Some cards become much longer than others. Long default descriptions cause uneven scanning and wasted or crowded space.
4. **Trend is not visually obvious.** Percentages convey endpoint changes but not the path taken. Users cannot quickly tell whether a movement was smooth, volatile, or reversed.
5. **The label «بالا» is ambiguous.** It is unclear whether it refers to price level, trend, volatility, or the strength of a signal. Do not preserve it without inspecting its actual meaning and calculation.
6. **Explanations can sound more certain than the data allows.** Describing a movement and explaining its causes are different tasks. A cause should be named only when supporting evidence exists.
7. **Data freshness is easy to overlook.** Different cards may update at different times, so the interface must not imply that all readings are synchronized if they are not.
8. **The card layout needs a disciplined responsive strategy.** Desktop columns are reasonable at wide widths, but simply shrinking them would make Persian copy and numeric values difficult to read on mobile.

## 3. Design direction: premium editorial

Aim for the quality of a professional financial publication:
- calm, precise, readable, and data-first;
- ample but controlled whitespace;
- consistent spacing and alignment;
- restrained color accents instead of loud red/green verdict badges;
- no gratuitous gradients, glow, fake 3D, heavy shadows, or decorative elements that compete with the price;
- clear typography and tabular numerals for numeric values;
- shared site tokens/components wherever possible.

Do not turn the cards into trading terminals or imply a trading recommendation. Preserve the current overall product style where it works.

## 4. Card order

Default order should be:
1. Gold
2. Silver
3. Oil
4. Bitcoin

This keeps precious metals adjacent. Inspect existing user-configurable ordering or persistence before changing it. If the product supports user-defined order, do not remove that capability; apply the proposed order as a default only where compatible.

Do not reorder assets dynamically by daily change, volatility, or an unannounced ranking.

## 5. Content architecture

### Default/collapsed card
- Asset title.
- Current/latest price and unit.
- Compact data freshness indicator.
- Primary seven-day trend visualization and a carefully defined trend description, where available.
- Latest daily change as secondary information.
- One short evidence-grounded market summary.
- A “More details” disclosure control.

### Expanded details
Retain useful information that already exists:
- weekly, monthly, and annual returns;
- 52-week high/low or range;
- historical records and their dates, if reliable and useful;
- contract/instrument details;
- source, exact as-of timestamp, and data-quality notes;
- relevant additional statistics already supported by the application.

Keep the existing statistic definitions unless repository inspection finds an error. Do not silently change the meaning of returns, dates, benchmark, currency, or units as part of a visual refactor.

## 6. Evidence-first briefing

The short summary should describe what the available data supports. Use a hierarchy of evidence:
- **Observed movement:** directly calculated from price data, such as a change over the defined seven-day window.
- **Observed related metric:** a current value for a relevant and documented external indicator, if the application provides it.
- **Interpretation:** a restrained statement based on explicit rules or analysis.
- **Possible driver:** may be mentioned only when the application has timely, relevant corroborating evidence and a documented basis for linking it to the movement.

When only the price series is available, say what the price did; do not invent why it happened.

The default summary should usually be one or two short sentences. If evidence is sparse, say so. Do not force every asset to have a causal narrative.

## 7. Financial communication standard

- Describe direction over a specific timeframe rather than making open-ended predictions.
- Use “has risen,” “has declined,” “appears to be moving within a range,” “may reflect,” and “the available data suggests.”
- Avoid “will rise/fall,” “guaranteed,” “certain,” “strong buy/sell,” “safe,” or similar definitive claims.
- Do not translate a simple return into a probability of a future outcome.
- A “trend” label is a description of past/current data over a defined horizon, not a forecast.
- Be particularly careful with Bitcoin: short-term movements and volatility can be large; avoid confident explanations or directional verdicts based only on a seven-day price line.

## 8. What not to change

- Do not redesign the page heading, overall page structure, unrelated sections, navigation, or global styles.
- Do not remove the deeper statistics; move them into progressive disclosure.
- Do not introduce a new market-data provider just to support the visual redesign without evaluating current sources and obtaining approval where needed.
- Do not add a new charting dependency without demonstrating that existing tools cannot meet the requirement.
- Do not alter asset definitions, price benchmarks, or trading-session assumptions without documenting and reviewing the change.
