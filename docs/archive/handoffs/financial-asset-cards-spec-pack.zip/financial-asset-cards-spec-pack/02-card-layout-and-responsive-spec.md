# 02 — Card Layout, Hierarchy, and Responsive Specification

## 1. Scope and implementation approach

Scope is limited to the individual asset cards and their immediate internal layout. Refactoring the card component, data contract, or related helper functions is allowed when beneficial. Keep unrelated page behavior intact.

The implementation agent must first inspect current tokens, fonts, component conventions, and breakpoints. Use the site's existing design system before creating new styles.

## 2. Default card hierarchy

Use this approximate order:

1. **Identity row:** icon and asset name.
2. **Price row:** current/latest price as the dominant value; unit attached as smaller secondary text.
3. **Freshness:** compact update timestamp/status, visually secondary but discoverable.
4. **Seven-day trend area:** trend period label, compact sparkline, and carefully worded trend description or movement.
5. **Daily change:** secondary comparison, clearly labelled with its exact period.
6. **Briefing summary:** one or two concise evidence-grounded sentences.
7. **Disclosure:** “More details” / «جزئیات بیشتر».

The card title must not visually subordinate itself to the unit. The price is the dominant numeric anchor; the title is the dominant identifying label.

## 3. Typography starting points

These are starting values, not hard requirements. Reconcile them with the existing system, available Persian font metrics, device sizes, and accessibility needs.

| Element | Desktop starting point | Suggested weight | Notes |
|---|---:|---|---|
| Asset title | 16–18 px | Semibold | Must read clearly as the card identity |
| Current price | 26–32 px | Bold | Primary numeric element; use tabular numerals if supported |
| Price unit | 12–13 px | Regular/medium | Adjacent to price, lower visual emphasis |
| Seven-day trend label | 13–14 px | Medium | Explicitly identify the horizon |
| Daily change | 12–14 px | Medium | Secondary to the overall trend |
| Briefing | 13–14 px | Regular | Comfortable reading line-height; typically 1.5–1.8 for Persian |
| Freshness/source metadata | 11–12 px | Regular | Must remain legible and not be the only place important status is communicated |

Avoid making secondary metadata so small that it becomes illegible on mobile. On narrow screens, reduce spacing before reducing type size.

## 4. Price and unit alignment

- Keep current price and unit visually grouped as one concept.
- Price should dominate the unit in size and weight.
- Do not place the unit in a stronger font size than the asset title.
- Keep grouping intact in both RTL and LTR.
- Prevent the unit from wrapping to an unrelated line if there is a reasonable alternative layout; when a wrap is unavoidable, preserve semantic grouping.
- Use locale-aware formatting for decimal separators, digit shaping, grouping separators, signs, and units.
- Apply tabular numerals where the font supports them to reduce visual jitter when values update.
- Use the actual instrument's correct unit and benchmark; do not assume all assets use the same currency or quantity unit.
- If the price is unavailable, show an explicit unavailable state instead of zero or a stale-looking placeholder.
- Avoid excessive decimal precision. Match precision to the instrument, source quality, and existing product conventions.

## 5. Card composition and spacing

- Use consistent inner padding and spacing tokens.
- Align repeated elements across cards where this improves comparison: icon size, title baseline, price row, trend section, summary start, and disclosure position.
- Allow card height to grow naturally with text and expanded details. Do not clip content to force equal heights.
- Use a stable layout for the identity row so long asset names do not collide with price or icons.
- Keep the icon supportive, not larger or more visually prominent than the asset name and price.
- Avoid excessive nested borders or repeated section dividers.
- Ensure the trend chart is compact and supports the narrative rather than becoming the visual focus.
- Maintain readable line lengths in explanatory text.
- Details expansion should not cause focus loss or unexpectedly jump the page.

## 6. Seven-day trend presentation

- Label the chart horizon clearly, for example «روند ۷ روز گذشته» / “Past 7 days”.
- A sparkline should be visually compact, have sufficient stroke contrast, and avoid unnecessary axes or gridlines.
- The sparkline must be paired with accessible textual information about the movement; it cannot be the only source of meaning.
- Do not show a trend badge if the trend classification is not calculated by a documented method.
- Do not encode unsupported strength through line thickness, dramatic slope, animated movement, or saturated colors.
- If the trend is mixed/unclear under the documented method, present it as such.
- If the data is missing or stale, do not draw an invented flat line.

## 7. Color and status

- Use restrained semantic accents for direction.
- Direction must also be communicated through a label or icon, not color alone.
- Do not present green as a recommendation to buy, or red as a recommendation to sell.
- A negative daily move can coexist with a positive seven-day trend. Display each with its own explicit period so they are not contradictory.
- Neutral, mixed, unknown, stale, and unavailable states must have distinguishable text.
- Keep visual intensity proportional to the informational meaning, not to an attempt to make the market look exciting.

## 8. Expanded detail section

- Implement with the project's existing accessible disclosure/accordion pattern where available.
- Button text and state must make it clear that the section can expand and collapse.
- In the expanded section, preserve current detailed statistics unless they are demonstrably wrong or obsolete.
- Group related information into readable blocks, not one dense paragraph.
- Keep labels and units adjacent to values.
- Include source and as-of time if available.
- The complete details must remain reachable by keyboard and assistive technologies.
- Expansion must work independently per card unless the existing product has an intentional “expand all” behavior.

## 9. Responsive behavior

### Desktop / wide screens
- Preserve the existing card grid if it fits the available width.
- Use consistent columns and gaps; avoid stretching copy across excessively long lines.
- Keep titles, price and trend information visible without forcing a large amount of vertical scrolling.
- Long descriptions should be constrained by a readable line length, not clipped.

### Tablet
- Use two columns when this preserves comfortable card width and readable copy.
- Stack to one column if the actual viewport or localization causes cards to become too narrow.
- Preserve the same hierarchy; do not simply shrink every font.
- Ensure the sparkline has sufficient width for a meaningful trend shape.

### Mobile
- Use one column by default unless repository inspection shows a better established pattern.
- Identity, price/unit, freshness, trend, daily change, and summary remain in a predictable sequence.
- Avoid four-column or cramped two-column layouts for text-heavy cards.
- Use flexible height and natural text wrapping.
- Ensure no horizontal page scroll at 320 CSS pixels or the narrowest supported viewport.
- Keep disclosure controls easy to tap and ensure their text is not truncated.
- If the chart is compacted, retain the seven-day label and equivalent textual description.
- Do not hide essential freshness or unavailable-data messages solely to save space.

Breakpoint thresholds should follow existing project conventions. If none exist, derive them from content fit and document the chosen values and rationale.

## 10. Asset order

Default order: Gold, Silver, Oil, Bitcoin. Respect any intentional user-configurable ordering in the existing product. Do not dynamically sort by performance unless such a feature already exists and the user has explicitly enabled it.
