# 04 — Data, Trend Semantics, and Seven-Day Sparkline

## 1. Principle

The sparkline and trend summary must be based on real observations supplied by the application's data sources. This is a data-integrity requirement, not merely a visual requirement.

Do not create synthetic price points, draw a flat placeholder line, or reuse data from a different instrument if the requested history is unavailable.

## 2. Repository investigation before technical decisions

Trace the current asset card data path:
- source/provider and endpoint;
- instrument identifier and benchmark;
- current price and unit;
- currency denomination;
- timestamp semantics (observation time, market close, fetch time, or publication time);
- daily percentage-change calculation;
- weekly/monthly/annual return definitions;
- historical high/low computation;
- any existing trend label, score, thresholds, or signal calculation;
- caching/refresh behavior;
- missing observations, revisions, and stale-data policy.

Do not assume a given API is suitable for historical data just because it returns a current price. Inspect its contract and actual data coverage.

## 3. Sparkline data contract

Use real price observations for the selected asset and instrument, with enough points to describe the last seven calendar days or the established seven-day market window. The exact convention must match the underlying feed and be documented.

Each point should contain, at minimum:
- timestamp with clear timezone semantics;
- price value;
- instrument/benchmark identity;
- currency and unit or a reference to their stable definition;
- validity/quality status if supplied by the source.

Rules:
- Sort observations by timestamp before rendering.
- Do not mix spot and futures prices, different contract months, currencies, exchanges, or benchmarks in a single line unless that conversion/roll logic is explicitly part of the current product and documented.
- Avoid duplicate timestamps or invalid/non-finite prices.
- Do not interpolate across long gaps in a way that implies observed prices where none exist.
- Preserve genuine gaps or show an incomplete-data state according to the charting approach.
- If only too few valid observations are available, do not imply a reliable seven-day shape; display a clear unavailable/incomplete state.
- The chart and numeric seven-day comparison must use the same time window and compatible source semantics.
- Document whether the window is rolling 7 × 24 hours or seven calendar days. Use one convention consistently per supported asset category unless the existing product has a valid, user-visible alternative.

## 4. Rendering rules

- A small SVG/canvas/chart primitive is preferred if already available and suitable. Inspect existing dependencies before adding one.
- Keep the sparkline compact and visually secondary to the current price.
- It should have a clear accessible label such as “Price movement over the past seven days.”
- Avoid unnecessary axes/gridlines for a sparkline, but preserve an adequate visual baseline and line clarity.
- Do not use dramatically thick strokes or saturated color to amplify a minor move.
- Scale the y-axis to the displayed window in a mathematically consistent way. Recognize that independently scaled sparklines are useful for local shape but cannot be compared by absolute vertical height across assets.
- Do not imply comparable magnitude by making one card's line appear higher than another's; percentage-change text gives the more direct cross-asset comparison.
- Where meaningful, indicate the start-to-end movement as text; do not rely on the shape alone.
- Avoid animation that suggests a forecast or emphasizes small price changes.

## 5. Define “trend” before showing a trend label

A seven-day return and a trend classification are not identical. A net increase may contain sharp reversals; a small net change can include high volatility.

During repository inspection:
1. Find whether a trend-classification algorithm already exists.
2. Document its inputs, period, thresholds, treatment of noise, and state meanings.
3. Check whether its output is actually used in the current «بالا» label.
4. Determine whether that label can be defended and communicated accurately.
5. If no suitable calculation exists, propose one based on available history and review it before implementation.

Do not silently invent a complex technical indicator or use an undefined “AI trend score.” A simple descriptive comparison may be more honest than a categorical badge.

If a direction label is eventually used, use documented thresholds or an existing defensible classification. Consider a neutral/mixed result when the direction is weak or the series is volatile. Do not tune thresholds only to make the UI look decisive.

## 6. Daily change versus seven-day trend

These are separate facts and must carry separate labels.

- Seven-day trend is the primary movement story.
- Daily percentage change is supporting information.
- A positive daily return may coexist with a negative seven-day return, and vice versa.
- Do not label the overall seven-day trend from today's percentage alone.
- Ensure calculation endpoints and time zones are consistent.
- If the feed's “daily” change actually means change since market close or since the prior quote, name it accurately rather than assuming it means a rolling 24 hours.

## 7. Summary data and evidence

The briefing should preferably be generated from deterministic templates/rules using:
- validated seven-day movement;
- daily change;
- an existing documented trend classification, if valid;
- related indicators only when they are actually available, relevant, timestamped, and sourced.

Do not make up external context to fill the card. A price-only card can provide a useful price-only summary.

If an explanation mentions interest rates, currency movements, physical supply/demand, industrial demand, market flows, positioning, or an event, the agent must demonstrate that the relevant data or documented evidence is present and temporally appropriate. Otherwise, do not mention it as the explanation for the move.

## 8. Freshness and market schedules

- Apply a freshness rule appropriate to the asset and source. Do not assume a commodity benchmark and a continuously traded crypto asset follow the same schedule.
- Distinguish the observation timestamp from the time the app fetched or cached the response.
- Display delay or stale state when material.
- Do not compare assets as if their timestamps are synchronized when they are not.
- If an asset is closed or its underlying benchmark updates only during specific sessions, retain its legitimate last observation and timestamp rather than describing it as an error.
- For continuously traded instruments, do not silently treat an old quote as current.
- If data is stale, suppress or qualify conclusions that depend on it.

## 9. Volatility and Bitcoin

- Keep wording descriptive and horizon-specific.
- Do not use the size of one short-term price move alone as evidence of a persistent trend.
- If the app has a documented volatility measure, it may be shown in expanded details; do not invent a value.
- Avoid escalating colors, alarm icons, or highly confident badges based solely on a large move.
- If the seven-day series shows large reversals, the summary should acknowledge choppy/uneven movement where supported.
- Do not predict continuation or reversal from the sparkline.
- Do not assume that Bitcoin's volatility is always higher at every observation; make relative claims only with comparable measured data and a defined period.

## 10. Units, returns, and numerical integrity

- Preserve the existing correct instrument, benchmark, currency, and unit definitions.
- Validate numeric values before formatting.
- Avoid floating-point display artifacts.
- Consistently define the return calculation, e.g. `(end / start - 1) × 100`, if this matches the existing product definition.
- For a requested comparison window, verify both endpoints are valid and appropriately timestamped.
- Do not report 0% when the change could not be calculated.
- Avoid over-precision in the visible card; retain appropriate raw precision internally.
- Keep historical high/low labels and dates tied to the correct historical coverage. “All-time high” must not actually mean the maximum since the API started collecting data unless the UI explicitly qualifies that limitation.

## 11. When to fall back

- No valid seven-day history: show “Seven-day trend unavailable” and continue to show a valid current price if available.
- Insufficient points or material gaps: disclose incomplete history; do not draw an authoritative trend line.
- No trend algorithm: a clearly labelled “seven-day price movement” may be shown if calculated, but do not invent a categorical trend.
- No corroborating driver data: provide an observed-movement summary only.
- Stale input: indicate staleness and qualify the summary.
- Failed fetch: show an error or unavailable state, not a fabricated flat line.

## 12. Model/data changes

Any change to calculations must be isolated, documented, and covered by tests. Do not rewrite financial formulas as incidental UI cleanup. If a current calculation is ambiguous or likely wrong, report it in the audit and propose the correction separately.
