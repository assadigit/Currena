# 07 — Coding Agent Prompt: Financial Asset Price Cards

You are a senior UI/UX designer and frontend engineer working on an existing financial website. Your task is to audit and improve the individual asset price cards shown for gold, silver, oil, Bitcoin, and any related assets already supported by the application.

The user is a vibe-coder and not an economist. Explain material decisions in plain language. Do not expect the user to infer technical assumptions.

## Confirmed requirements

- Scope is the asset cards only. Do not redesign the page-level heading or unrelated page sections.
- Visual direction: premium editorial, restrained, clear, professional.
- Primary movement story: recent trend over the past seven days.
- Keep the daily percentage change as supporting information.
- Use a real-data seven-day sparkline.
- Use deterministic, evidence-grounded briefing rules based on available data; do not invent news or causes.
- Move weekly/monthly/annual returns, 52-week range, historical records, and other useful detailed statistics into an expandable section.
- Inspect the meaning and calculation of the existing «بالا» label. Keep it only if defensible, rename it only when the underlying metric is understood, otherwise propose removing it.
- Default asset order: Gold → Silver → Oil → Bitcoin, preserving any intentional user-configurable ordering that exists.
- Persian RTL and English LTR must both work.
- Cautious, hedged market language is mandatory, particularly for volatile assets such as Bitcoin.
- Refactoring the component/data model is allowed if needed, but unrelated functionality must be preserved.
- Do not implement while preparing the audit/specification. The current task is an investigation and plan first.

## Read first

Read every specification file in this pack:
- `01-audit-and-design-direction.md`
- `02-card-layout-and-responsive-spec.md`
- `03-ux-writing-fa-en.md`
- `04-data-trend-and-sparkline-spec.md`
- `05-accessibility-localization-and-failure-states.md`
- `06-acceptance-criteria-and-test-plan.md`

Use these as requirements, adapting only when repository evidence reveals a real constraint. Document any conflict and its rationale.

## Phase 1 — Repository audit (no code changes)

Inspect the actual repository and identify:
1. Framework, build system, styling approach, design tokens, typography, icons, breakpoints, themes, localization, and test tooling.
2. The existing asset-card component(s) and their component/data dependencies.
3. The current source/API for every displayed price and historical series.
4. Definitions of current price, instrument benchmark, unit, currency, daily change, weekly/monthly/annual returns, 52-week range, and historical records.
5. The actual calculation and meaning of the current «بالا» label.
6. Data freshness, caching, refresh schedules, time zones, missing-data behavior, and error behavior.
7. Existing language-switching/RTL behavior and any user-configurable ordering.
8. Relevant tests and current build/lint/type-check commands.
9. Which unrelated page features must remain unchanged.

Cite exact source paths and function/component names in the audit. If the repository is not accessible, stop and ask for repository access or the minimum required source files; do not pretend to have inspected it.

## Phase 2 — Data and trend review (no code changes)

- Verify that the existing data source can provide real historical price observations for the last seven days.
- Check whether current price and history refer to the same instrument, benchmark, currency, and unit.
- Document whether the window is rolling seven days or a calendar-day window.
- Trace how “daily” change is calculated; do not assume it means rolling 24 hours unless it actually does.
- Determine how gaps, duplicate timestamps, stale prices, and failed historical requests are handled.
- Assess whether the existing trend label is based on a defined method or an unsupported/static rule.
- If the data does not support a reliable classification, propose displaying the observed seven-day movement without a categorical directional badge.
- Do not create synthetic prices or a fake flat line if history is unavailable.

## Phase 3 — UX and implementation plan (no code changes)

Provide:
- Summary of the current UI problems.
- Recommended card structure and typographic hierarchy based on existing tokens.
- Proposed approach to the seven-day sparkline and its accessible text equivalent.
- Plan for daily change as supporting information.
- Treatment of the «بالا» label.
- Concise Persian and English evidence-based copy.
- Mobile/tablet/desktop behavior.
- Loading, stale-data, partial-history, API-failure, and missing-data states.
- Accessibility and RTL/LTR plan.
- List of files likely to change and why.
- Any dependencies proposed and their justification.
- Risks and regression checks.
- Implementation tasks ordered into small reviewable steps.

**Stop after the audit and plan and present them to the user for approval.** Do not make code changes in these phases unless the user has separately instructed implementation in the same session.

## Phase 4 — Implementation (only after approval)

When approved:
1. Reuse the project's existing styling, localization, data-fetching and charting conventions where appropriate.
2. Refactor only the card components and supporting code needed for the agreed scope.
3. Make the seven-day trend the primary movement story and daily change secondary.
4. Ensure price and unit form a clear visual group; title is an identifying heading, unit is secondary metadata.
5. Use real timestamped price observations, with correct instrument/currency/unit and documented window boundaries.
6. Handle missing or stale history honestly. Never fabricate a chart.
7. Generate summaries from available evidence and explicit rules. No unsupported causal attribution, prediction, probabilities, or buy/sell recommendation.
8. Treat Bitcoin and other volatile assets cautiously; avoid implying a short-term move will persist.
9. Preserve all useful detailed statistics in the expandable section.
10. Keep Persian RTL and English LTR correct.
11. Implement accessible expansion controls, chart descriptions, focus styles, and state announcements.
12. Preserve page-level layout and unrelated functionality.
13. Add or update tests for calculations, formatting, loading/error/stale states, and responsive/localized behavior.
14. Run build, lint, type checks, and tests available in the repository.

## Critical financial-writing safeguards

Never:
- present past movement as a prediction;
- invent a reason for a price move from price data alone;
- turn a percentage change into a probability;
- use “will rise/fall,” “guaranteed,” “certain,” or trading instructions;
- mistake a daily change for a seven-day trend;
- treat missing data as a flat/neutral movement;
- describe stale quotes as current;
- use alarmist styling for a market move or an API error.

Use cautious descriptions such as “has risen over the past seven days,” “the available data suggests,” “movement has been uneven,” or “no clear direction is evident,” only when supported by the relevant observations.

## Required final implementation report

- Summary of changes and rationale.
- Exact files changed.
- How the trend label was defined or removed.
- Historical data source, timeframe, and gap handling.
- How the sparkline aligns with the displayed data.
- Copy rules and examples.
- Responsive, RTL/LTR, and accessibility decisions.
- Tests executed and pass/fail outcomes.
- Before/after screenshots if available.
- Known limitations and uncompleted checks.
