# 05 — Accessibility, Localization, and Failure States

## 1. Accessibility target

Aim for WCAG 2.2 AA where applicable and in line with the existing product standard.

- Use semantic headings and descriptive grouping for each asset.
- Ensure keyboard users can operate the details disclosure.
- Show a visible keyboard-focus indicator.
- The disclosure control must expose expanded/collapsed state through the project's accessibility conventions.
- Direction must not be communicated by color alone. Include a text label, sign, or equivalent.
- Provide a useful accessible description for the sparkline, including asset and time window. If the chart is decorative because its meaning is fully conveyed in text, it can be hidden from assistive technology; do not leave an informative graph with no accessible equivalent.
- Do not announce every data refresh or point change noisily. Announce meaningful state transitions only when appropriate.
- Respect reduced-motion preferences.
- Hover/focus must not be the only route to essential information.
- Maintain accessible contrast for body text, labels, chart lines, focus rings, and borders.
- Ensure touch targets meet the project's standards and applicable accessibility guidance.
- Test keyboard navigation and screen-reader ordering in Persian RTL and English LTR.

## 2. Persian RTL and English LTR

- Follow the repository's current localization architecture.
- Persian uses RTL text flow; English uses LTR.
- Keep the semantic meaning of trend states consistent in both languages.
- Use logical spacing/layout properties where supported by the stack.
- Keep price and unit semantically grouped; verify how numbers and Latin currency codes render in RTL.
- Format decimals, thousands separators, percentages, and dates through locale-aware utilities.
- Avoid concatenating sentence fragments when grammar changes with locale.
- Provide translated labels for all loading, empty, stale, partial-data, failed-fetch, and expanded/collapsed states.
- Test mixed-script titles, numbers, tickers, units, and timestamps.
- Do not assume the page's outer direction can be safely set on the card alone; inspect existing language-switching behavior.

## 3. Data states are distinct

| State | Expected UI behavior |
|---|---|
| Loading initial data | Show a deliberate loading state; do not show zero values or a fake line |
| Current price available, history missing | Show price and unit; mark trend unavailable |
| History partly missing | Show incomplete-history note or omit line according to documented policy |
| Stale quote | Preserve the timestamp; mark data as delayed/stale and qualify the summary |
| Fetch fails, no cached reading | Show price unavailable and a retry path if the app already supports retries |
| Fetch fails, cached reading exists | Clearly identify the last successful timestamp and avoid implying it is current |
| Invalid price or non-finite value | Reject safely; do not render NaN/Infinity or a misleading zero |
| Missing unit or unknown instrument identity | Do not guess; show an appropriate error state or block display |
| Expanded details loading/failing | Keep the card usable and show the details' loading/error state locally |
| Different asset timestamps | Show per-asset freshness; do not imply synchronization |
| No clear trend | Use a neutral/mixed description rather than forcing up/down |
| Trend rule unavailable/unvalidated | Do not show a calculated trend badge; describe only what is directly observed |

## 4. Caching and refresh

- Preserve existing refresh semantics unless an issue is discovered and approved.
- If cached data is shown, identify its actual update time and stale state.
- Avoid a flashing empty state between refreshes when a previously valid value can be displayed safely.
- Do not label a value “live” unless its data source and timestamp semantics justify that claim.
- If refresh fails, distinguish the last known value from current availability.
- Make refresh failures visible but not alarmist.
- Avoid repeatedly announcing identical errors to assistive technology.

## 5. Failure behavior and graceful degradation

- If the sparkline cannot render, the price and text summary must remain usable.
- If the chart dependency or API is unavailable, do not replace the chart with fictional points.
- If briefings cannot be computed because data is insufficient, show a short explanation instead of generic commentary.
- If the optional details section fails, keep the main price card intact.
- Do not let one failed asset break the whole grid.
- Error states should not look like adverse market signals.
- Do not use red directional styling for an API error; system status and market direction are different concepts.

## 6. Security and rendering

- Treat API-provided asset names and summaries as untrusted data.
- Use the framework's safe text rendering; do not inject arbitrary HTML.
- Ensure user- or provider-supplied text cannot break card layout.
- Bound very long text or provide progressive disclosure without permanently hiding important information.
