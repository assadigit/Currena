# 03 — Financial UX Writing (Persian and English)

## 1. Voice and intent

The voice should resemble a careful financial publication: clear, calm, succinct, and explicit about uncertainty.

The product is briefing users on available data. It is not promising future returns and should not sound like a trading signal generator.

### Prefer
- Descriptions tied to a defined timeframe.
- “has risen/declined,” “appears to be moving within a range,” “the available data suggests,” “may be consistent with,” “could reflect,” “no clear direction is evident.”
- A clear distinction between observed facts and interpretation.
- Plain Persian that a general reader can understand.
- Explicit data limitations when they materially affect the summary.

### Avoid
- “will rise,” “will fall,” “guaranteed,” “certain,” “risk-free.”
- “buy now,” “sell now,” “strong buy,” “strong sell.”
- unsupported causal claims such as “the price rose because of X” when only the price series is available.
- arbitrary confidence percentages.
- overconfident short-term calls, especially for Bitcoin.
- generic filler text that says nothing specific about the data.

## 2. Primary trend labels

Use these only if the trend algorithm or existing state logic provides a documented basis.

| State | Persian label | English label |
|---|---|---|
| Recent movement upward | روند اخیر صعودی بوده است | Recent movement has been upward |
| Recent movement downward | روند اخیر نزولی بوده است | Recent movement has been downward |
| Range-like movement | حرکت اخیر عمدتاً در یک محدوده بوده است | Recent movement has been mostly range-bound |
| Mixed/unclear | جهت مشخصی دیده نمی‌شود | No clear direction is evident |
| Insufficient evidence | دادهٔ کافی برای ارزیابی روند وجود ندارد | Not enough data to assess the trend |
| Stale data | داده‌ها به‌روز نیستند | Data may be outdated |
| Unavailable | روند فعلاً قابل ارزیابی نیست | Trend is currently unavailable |

These phrases describe a defined recent window. They are not forecasts. Do not infer “bullish” or “bearish” from one daily move alone.

## 3. Example short summaries

These examples illustrate the cautious style. They are not claims about current market conditions.

### Gold — price-only evidence
**Persian:** «قیمت طلا در هفت روز گذشته افزایش یافته است. این تغییر، روند همین بازه را نشان می‌دهد و به‌تنهایی جهت حرکت آینده را مشخص نمی‌کند.»

**English:** “Gold has risen over the past seven days. This describes the selected period and does not, by itself, establish the next move.”

### Silver — mixed movement
**Persian:** «نوسان قیمت نقره در این بازه یکدست نبوده است؛ بنابراین، داده‌های فعلی جهت روشنی را نشان نمی‌دهند.»

**English:** “Silver's movement has been uneven over this period, so the available data does not show a clear direction.”

### Oil — observed trend and supported context
**Persian:** «قیمت نفت در این بازه افزایش یافته است. برای توضیح عوامل مؤثر، باید داده‌های مرتبط با عرضه، تقاضا و شرایط بازار نیز بررسی شوند.»

**English:** “Oil prices have risen over this period. Explaining the drivers would require supporting evidence about supply, demand, and market conditions.”

### Bitcoin — volatility-aware wording
**Persian:** «قیمت بیت‌کوین در هفت روز گذشته نوسان داشته است. تغییرات این بازه لزوماً ادامه‌دار نیست و می‌تواند در کوتاه‌مدت با نوسان بیشتری همراه شود.»

**English:** “Bitcoin has fluctuated over the past seven days. This movement may not persist, and short-term volatility can remain high.”

The Bitcoin example may only mention “fluctuated” when the observed series supports that characterization. Do not automatically describe Bitcoin as rising, falling, or unusually volatile without the relevant data and a defined comparison.

## 4. Evidence rule for explanations

A summary may include:
1. **Observed price behavior**, calculated from the card's price series.
2. **A relevant related metric**, if the application provides a timely value from a known source.
3. **An interpretation**, if supported by documented logic.
4. **A possible driver**, only when relevant corroborating evidence exists.

If the system only has price history, report price history. Do not invent news, macroeconomic causes, investor sentiment, positioning, flows, or causal links.

Avoid saying “because of” unless there is specific, defensible evidence for that causal attribution. When causation is uncertain, use “may be associated with” or omit the explanation.

## 5. Summary length

- Default: one or two sentences.
- Aim for approximately 20–40 words in Persian/English combined equivalent, but let factual clarity take precedence over an exact word count.
- Do not repeat the price, unit, or percentage already displayed unless the sentence adds context.
- Do not list every indicator or every return period.
- If the data supports no useful explanation, use a brief limitation message rather than filler.
- The full rationale and data can live in expanded details where available.

## 6. Freshness and error copy

| Situation | Persian | English |
|---|---|---|
| Recent update | آخرین به‌روزرسانی: {time} | Updated: {time} |
| Delayed/stale | ممکن است داده‌ها با تأخیر به‌روز شوند. | Data may be delayed. |
| Incomplete history | داده‌های این بازه کامل نیستند؛ نمودار ممکن است تصویر کاملی ارائه نکند. | Data for this period is incomplete; the chart may not show the full picture. |
| Price unavailable | قیمت فعلاً در دسترس نیست. | Price is currently unavailable. |
| Summary unavailable | برای ارائهٔ خلاصهٔ معتبر، دادهٔ کافی در دسترس نیست. | There is not enough data to provide a reliable summary. |
| Source timestamp unknown | زمان به‌روزرسانی مشخص نیست. | Update time is unknown. |

Do not display “Updated now” unless the source confirms that the displayed data is current.

## 7. Labels and details

| Purpose | Persian | English |
|---|---|---|
| Asset title | Use the asset's established product name | Established asset name |
| Price unit | Correct localized unit | Correct instrument unit |
| Past 7 days | هفت روز گذشته | Past 7 days |
| Daily change | تغییر روزانه | Daily change |
| More details | جزئیات بیشتر | More details |
| Less details | نمایش کمتر | Show less |
| 52-week range | بازهٔ ۵۲ هفته | 52-week range |
| Historical high | بیشترین مقدار تاریخی | Historical high |
| Historical low | کمترین مقدار تاریخی | Historical low |
| Data source | منبع داده | Data source |
| As of | تا زمان | As of |

Avoid keeping «بالا» without context. Inspect its current meaning and code. If it means price level, identify that precisely (e.g., relative to its own history); if it means recent trend, use a defined trend label; if no robust calculation exists, remove it rather than guessing.

## 8. Localization rules

- Keep copy in the existing translation/localization system.
- Persian must read naturally in RTL, with appropriate punctuation and number formatting.
- English must remain LTR.
- Keep units attached semantically to values in both directions.
- Use locale-aware formatting utilities, not hand-written separator replacements.
- Avoid concatenating translated sentence fragments.
- Provide translations for empty, loading, stale, unavailable, disclosure, and chart-accessibility text.
- Test mixed Persian and Latin content, including ticker symbols, currency codes, and URLs.
