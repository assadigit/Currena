# Financial Asset Price Cards — Implementation Specification Pack

**Version:** 1.0  
**Date:** 2026-10-17  
**Status:** Specification only. Do not implement the website as part of preparing these documents.

## Objective

Refine the existing asset price cards into a premium editorial, concise financial briefing. The primary story is the **recent trend over seven days**, with the latest daily move retained as supporting information. Show real, time-aligned price history with a compact sparkline, provide a cautious evidence-grounded summary, and move detailed statistics into an expandable area.

Confirmed decisions:
- Scope: asset cards only; do not redesign the page header or unrelated page sections.
- Primary movement: recent trend.
- Sparkline period: last 7 days.
- Briefing source: deterministic summaries grounded in available data and explicit rules, not free-form unsupported speculation.
- Detailed statistics: expandable section.
- Existing status label (currently shown as «بالا») must be inspected; retain only if its meaning and calculation are defensible.
- Asset order: Gold → Silver → Oil → Bitcoin.
- Visual direction: premium editorial.
- Implementation: refactoring the existing component/data model is allowed where necessary, while preserving unrelated functionality.
- Financial language: cautious, hedged, evidence-based; avoid strong verdicts and deterministic forecasts, particularly for volatile assets such as Bitcoin.

## Files

1. `01-audit-and-design-direction.md` — audit, intended experience, information hierarchy.
2. `02-card-layout-and-responsive-spec.md` — card structure, typography, alignment, visual system, responsive behavior.
3. `03-ux-writing-fa-en.md` — Persian and English copy, hedging rules, concise summaries.
4. `04-data-trend-and-sparkline-spec.md` — real data requirements, seven-day sparklines, trend semantics, evidence rules.
5. `05-accessibility-localization-and-failure-states.md` — RTL/LTR, accessibility, freshness, loading, missing data and error behavior.
6. `06-acceptance-criteria-and-test-plan.md` — testable requirements and verification plan.
7. `07-coding-agent-prompt.md` — ready-to-use prompt for the coding agent.

## Required execution order

1. Provide the agent access to the actual repository.
2. Have it read all specification files.
3. Require a repository audit before it assumes the framework, component architecture, styling system, data APIs, price units, or current calculations.
4. Require a brief implementation plan and confirmation of the existing trend/status-label logic.
5. Implement only after the audit/plan is reviewed or after the user explicitly authorizes implementation in that session.
6. Run the available tests and report any limitations.

## Important safeguards

- A seven-day sparkline must use real, timestamped price observations. Never generate illustrative/fabricated production data as a fallback.
- A price trend is not a forecast and a correlation is not proof of cause.
- Do not present an unsupported probability, buy/sell recommendation, certainty claim, or strong verdict.
- For Bitcoin and other highly volatile assets, prefer descriptive wording, clearly specified horizons, and stronger acknowledgement of uncertainty.
- Missing or stale data must not be presented as a flat/neutral trend.
- The displayed price, unit, data timestamp, percentage changes, and sparkline must refer to compatible instruments and data windows.

## Implementation constraint

The source repository was not included with this specification request. These files do not claim to know the project's framework, libraries, APIs, existing design tokens, data schema, or trend-calculation logic. The coding agent must inspect the repository before making technical choices.
