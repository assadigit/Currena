# Insights

- What the world’s money is doing: plain-language gauges, prices and indicators.
- Data as of: 2026-10-15
- Prices updated: 2026-10-15 22:13 UTC
- Rule version: 2

## Where things stand

| Indicator | Status | Details |
| --- | --- | --- |
| Global | Stressed | 6 of 23 in warning |
| Australia | Stressed | 6 of 14 in warning |

## Prices

| Indicator | Value | Unit | 7-day change | 30-day change | Position | Details |
| --- | --- | --- | --- | --- | --- | --- |
| Oil price (Brent) | 105.65 | US$ | 1.31 | -2.85 | expensive | One bitcoin buys 19.6 oz of gold · One bitcoin buys about 1430 oz of silver |
| Gold price (ounce) | 4191.7 | US$ | 0.83 | -3.26 | expensive | Gold price in Australian dollars: 5979.8792 · One bitcoin buys 19.6 oz of gold · One bitcoin buys about 1430 oz of silver |
| Silver price (ounce) | 57.6 | US$ | -2.48 | -8.91 | expensive | One bitcoin buys 19.6 oz of gold · One bitcoin buys about 1430 oz of silver |
| Bitcoin price | 82360.58 | US$ | 0.84 | 8.92 | expensive | One bitcoin buys 19.6 oz of gold · One bitcoin buys about 1430 oz of silver |

## World stock markets

| Market | Today % | 3 months % | From 52-week high % | Trend | Status | Last close | 52-week high | 52-week low | As of | Source |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KOSPI | -0.44 | -11.9 | -34.07 | Down | Bear market | 6008.81 | 9114.55 | 3561.81 | 2026-10-14 | eodhd |
| Nifty 50 | -0.44 | -6.02 | -14.08 | Down | Correction | 22622.7 | 26328.55 | 22231.8 | 2026-10-14 | eodhd |
| Hang Seng | -0.13 | -2.78 | -13.06 | Down | Correction | 24314.17 | 27968.09 | 22671.86 | 2026-10-14 | eodhd |
| Shanghai Composite | -0.88 | -2.97 | -11.2 | Down | Correction | 3767.23 | 4242.57 | 3764.15 | 2026-10-14 | eodhd |
| CAC 40 | 0.58 | -6.02 | -9.77 | Down | Correction | 7873.11 | 8726.03 | 7665.62 | 2026-10-14 | eodhd |
| Nikkei 225 | -0.05 | 1.36 | -6.39 | Up | Normal | 67744.29 | 72366.34 | 46847.32 | 2026-10-14 | eodhd |
| ASX 200 | -0.64 | -1.28 | -5.86 | Down | Normal | 8727.9 | 9271.6 | 8365.9 | 2026-10-14 | eodhd |
| Euro Stoxx 50 | 0.38 | -1.48 | -5.51 | Down | Normal | 6190.37 | 6551.22 | 5501.28 | 2026-10-14 | eodhd |
| Dow Jones | -0.09 | -1.77 | -5.02 | Down | Normal | 51621.48 | 54349.12 | 45166.64 | 2026-10-14 | eodhd |
| DAX | 0.15 | 1.54 | -4.79 | Down | Normal | 25298.61 | 26569.99 | 22300.75 | 2026-10-14 | eodhd |
| Nasdaq 100 | -2.02 | 3.19 | -4.08 | Flat | Normal | 29950.82 | 31224.47 | 22953.38 | 2026-10-14 | eodhd |
| S&P/TSX Composite | -1.11 | 0.69 | -3.72 | Down | Normal | 35584.46 | 36957.6 | 29777.8 | 2026-10-14 | eodhd |
| TAIEX | 0.59 | 6.58 | -2.4 | Up | Normal | 48625.83 | 49822.55 | 26434.94 | 2026-10-14 | eodhd |
| FTSE 100 | 0.7 | 1.44 | -1.7 | Flat | Normal | 10724.9 | 10910.6 | 9354.6 | 2026-10-14 | yahoo |
| S&P 500 | -1.11 | 2.46 | -1.28 | Flat | Normal | 7718.94 | 7818.93 | 6343.72 | 2026-10-14 | eodhd |
| Ibovespa | -0.18 | 18.8 | -1.22 | Up | Normal | 206505.98 | 209066.9 | 141682.99 | 2026-10-14 | eodhd |

## World currencies

| Pair | Today % | 1 month % | 3 months % | 1 year % | Trend | Rate | As of | Source |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Euro vs US dollar | 0.06 | -3.08 | -1.84 | -3.1 | Down | 1.12 | 2026-10-14 | frankfurter |
| US dollar vs yen | 0.21 | 2.52 | -2.32 | 4.17 | Flat | 158.45 | 2026-10-14 | frankfurter |
| Pound vs US dollar | 0.15 | -1.69 | -0.88 | 0.04 | Down | 1.33 | 2026-10-14 | frankfurter |
| US dollar vs Swiss franc | 0.13 | 2.07 | 2.68 | 3.58 | Up | 0.83 | 2026-10-14 | frankfurter |
| US dollar vs yuan | -0.02 | -0.23 | -1.29 | -6.26 | Flat | 6.69 | 2026-10-14 | frankfurter |
| Australian dollar vs US dollar | 0.46 | -1.68 | 0.97 | 8.64 | Down | 0.7 | 2026-10-14 | frankfurter |
| Australian dollar vs yen | 0.67 | 0.8 | -1.38 | 13.18 | Down | 111.07 | 2026-10-14 | frankfurter |
| Euro vs yen | 0.27 | -0.64 | -4.12 | 0.95 | Down | 177.38 | 2026-10-14 | frankfurter |
| Euro vs Swiss franc | 0.19 | -1.07 | 0.79 | 0.37 | Down | 0.93 | 2026-10-14 | frankfurter |
| Australian dollar vs yuan | 0.44 | -1.91 | -0.33 | 1.84 | Down | 4.69 | 2026-10-14 | frankfurter |

## Together

Relationships are general tendencies, not forecasts.

| Indicator | Status | Details |
| --- | --- | --- |
| Real yields and gold | Active | Real yields and gold usually move in opposite directions: when “safe” money pays more after inflation, gold tends to lose shine, and the other way round. — real yields: rising · gold: falling |
| Copper demand, Chinese factories and money | Active | Copper is wired into industry, so a firm copper-to-gold ratio tends to come with busy factories. (The link to US money supply is weak, so that leg is no longer counted.) — the copper price vs gold: rising · Chinese factory activity: rising |
| The dollar, gold and oil | Partly active | Gold and oil are priced in US dollars, so a strong dollar tends to weigh on them, and a weak one tends to lift them. — the dollar: rising · gold: falling · oil: falling |
| Oil, inflation expectations and borrowing costs | Partly active | When oil jumps, markets tend to expect more inflation, and long-term borrowing costs tend to rise with it. — oil: falling · inflation expectations: steady · 10-year borrowing costs: rising |
| Iron ore, the terms of trade and the Australian dollar | Partly active | Iron ore is one of Australia’s biggest exports, so firm export prices tend to lift the terms of trade and, over time, the Australian dollar. The US dollar rides along as context: a falling Australian dollar is often mostly a rising US dollar. — iron ore: rising · the terms of trade: falling · the Australian dollar: falling · the US dollar: rising |
| The RBA rate, home loans and household debt | Pass-through pending | When the RBA changes the cash rate, the home-loan rates people actually pay tend to follow one to three months later; the card reads pass-through pending until that data exists. (The debt leg is a debt-to-income level, not a debt-servicing cost.) — the RBA cash rate: rising · the home-loan rate people pay: steady · household debt ratios: rising |

## What the signals say

The conditions that usually surround each metal, in plain words: conditions, not forecasts, and not advice.

| Indicator | Conditions right now | Details |
| --- | --- | --- |
| gold | mostly unsupportive | 0 of 5 conditions met — Real yields: Works against · Inflation expectations: Sitting neutral · Market stress: Works against · The US dollar: Works against · Price footing: Works against |
| silver | mostly unsupportive | 1 of 6 conditions met — Real yields: Works against · Inflation expectations: Sitting neutral · Market stress: Works against · The US dollar: Works against · Price footing: Works against · Industrial demand: Supports |

## Indicators

| ID | Indicator | Ticker | Value | Unit | Status | 7-day change | 30-day change | 10-year position | As of | Snapshot time | Source |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| yield-curve-10y2y | The gap between 10-year and 2-year US borrowing |  | 0.37 | pts | Normal | -0.14 | 0.05 | 0.490188 | 2026-10-14 | 2026-10-15T09:13:13.847Z | FRED (T10Y2Y) |
| real-yield-10y | US 10-year interest after inflation |  | 2.88 | % | Needs attention | -0.03 | 0.28 | 0.996394 | 2026-10-13 | 2026-10-15T09:13:13.847Z | FRED (DFII10) |
| us10y | What the US government pays to borrow for 10 years |  | 5.21 | % | Needs attention | -0.06 | 0.25 | 0.995994 | 2026-10-13 | 2026-10-15T09:13:13.847Z | FRED (DGS10) |
| fed-target | The US central bank’s policy rate |  | 3.75 | % | Normal | 0 | 0.25 | 0.681831 | 2026-10-14 | 2026-10-15T09:13:13.847Z | FRED (DFEDTARL/U) |
| fed-expectations | What markets expect from the Fed | 2-year gap | 1.04 | pts | Needs attention | 0 | -0.09 | 0.91226 | 2026-10-13 | 2026-10-15T09:13:13.847Z | FRED (DGS2 − DFEDTARL) |
| us30y | US 30-year Treasury yield | 30-year | 5.56 | % | Needs attention | -0.08 | 0.21 | 0.995994 | 2026-10-13 | 2026-10-15T09:13:13.847Z | FRED (DGS30) |
| ecb-dfr | The euro area’s policy rate |  | 2.5 | % | Normal | 0 | 0.25 | 0.771507 | 2026-10-15 | 2026-10-15T09:13:13.847Z | ECB Data Portal (DFR) |
| govt-interest-revenue | The US government’s interest bill vs its income |  | 0.335539 | % | Normal |  | -0.001617 | 0.72973 | 2026-04-01 | 2026-10-15T09:13:13.847Z | FRED (BEA series, derived) |
| us-cpi-yoy | US prices vs a year ago | CPI | 3.717251 | % | Needs attention |  | 0.364235 | 0.752137 | 2026-09-01 | 2026-10-15T09:13:13.847Z | FRED (CPIAUCSL) |
| us-cpi-core-yoy | Core inflation | Core CPI | 2.565841 | % | Context |  | 0.119678 | 0.495726 | 2026-09-01 | 2026-10-15T09:13:13.847Z | FRED (CPILFESL) |
| breakeven-5y5y | Expected US inflation, five to ten years ahead |  | 2.34 | % | Normal | -0.01 | 0 | 0.881057 | 2026-10-14 | 2026-10-15T09:13:13.847Z | FRED (T5YIFR) |
| stress-stlfsi | Stress in US money markets |  | -0.7206 | index | Normal | -0.2531 | 0.0712 | 0.171154 | 2026-10-09 | 2026-10-15T09:13:13.847Z | FRED (STLFSI4) |
| nfci | US financial conditions |  | -0.494 | index | Normal | 0.016 | 0.055 | 0.533719 | 2026-10-02 | 2026-10-15T09:13:13.847Z | FRED (NFCI) |
| vix | Market fear gauge | VIX | 15.27 | index | Normal | 0.26 | -0.57 | 0.35234 | 2026-10-13 | 2026-10-15T09:13:13.847Z | FRED (VIXCLS), © Cboe |
| gold-silver | Gold’s price versus silver |  | 72.8 | ratio | Normal | 3.516251 |  | 0.246032 | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance (live ratio) |
| dollar-basket | The dollar vs six big currencies |  | 102.224744 | index | Normal | -0.184137 | 2.742127 | 0.737974 | 2026-10-14 | 2026-10-15T09:13:13.847Z | Currena basket (ECB rates via Frankfurter) |
| usdjpy | Dollar vs yen | USD/JPY | 158.45 | ¥ | Normal | 0.139038 | 2.523455 | 0.94955 | 2026-10-14 | 2026-10-15T09:13:13.847Z | Frankfurter (ECB) |
| eur-usd | Euro per US dollar | EUR/USD | 0.89326 | € | Context | -0.159832 | 3.179975 | 0.531873 | 2026-10-14 | 2026-10-15T09:13:13.847Z | Frankfurter (ECB) |
| china-pmi | Chinese factory activity |  | 50.1 | index | Normal |  | 0.3 |  | 2026-09-30 | 2026-10-15T09:13:13.847Z | China NBS (manual entry) |
| m2-us | The amount of money in the US economy | M2 money | 23342.8 | trillion | Normal |  | 0.537947 | 0.641026 | 2026-08-01 | 2026-10-15T09:13:13.847Z | FRED (M2SL) |
| philly-fed | US factory survey (Philadelphia Fed) | Philly Fed | 37.8 | pts | Normal |  | -9.6 | 0.949153 | 2026-09-01 | 2026-10-15T09:13:13.847Z | FRED (GACDFSA066MSFRBPHI), Philadelphia Fed |
| us-unemployment | US unemployment | BLS: UNRATE | 4.2 | % | Normal |  | 0.1 | 0.564103 | 2026-09-01 | 2026-10-15T09:13:13.847Z | FRED (UNRATE), US BLS |
| sahm-rule | US recession alarm (Sahm rule) | Sahm rule | 0 | pts | Normal |  | 0.07 | 0.324786 | 2026-09-01 | 2026-10-15T09:13:13.847Z | FRED (SAHMREALTIME) |
| copper-gold | Copper’s price versus gold |  | 3.351239 | ratio | Normal |  | 0.103449 | 0.211864 | 2026-09-01 | 2026-10-15T09:13:13.847Z | World Bank Pink Sheet |
| usdcny | Dollar vs Chinese yuan | USD/CNY | 6.6927 | CN¥ | Context | -0.17749 | -0.234035 | 0.255377 | 2026-10-14 | 2026-10-15T09:13:13.847Z | Frankfurter (ECB) |
| brent | Oil price (Brent) |  | 105.65 | US$ | Needs attention | 1.31 | -2.85 | 0.933333 | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance: Brent front-month futures (BZ=F) |
| gold-usd | Gold price (ounce) |  | 4191.7 | US$ | Context | 0.83 | -3.26 | 0.922006 | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance: COMEX gold futures (GC=F) |
| silver-usd | Silver price (ounce) |  | 57.6 | US$ | Context | -2.48 | -8.91 | 0.914411 | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance: COMEX silver futures (SI=F) |
| copper-usd | Copper price |  | 14772.999807 | US$ | Context | 1.958925 |  | 0.992063 | 2026-10-15 | 2026-10-15T09:13:13.847Z | gold-api.com (HG, history: World Bank) |
| btc-usd | Bitcoin price | BTC | 82360.58 | US$ | Context | 0.84 | 8.92 | 0.872329 | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance: Bitcoin spot index (BTC-USD) |
| gold-btc | Gold versus Bitcoin |  | 0.050894 | ratio | Context |  |  |  | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance (live ratio) |
| silver-btc | Silver versus Bitcoin |  | 0.000699 | ratio | Context |  |  |  | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance (live ratio) |
| au-cpi | Australian prices vs a year ago | CPI | 3.967855 | % | Needs attention |  | 0.51508 |  | 2026-08-01 | 2026-10-15T09:13:13.847Z | ABS (monthly CPI All groups) |
| au-trimmed-mean | Underlying inflation |  | 3.574018 | % | Needs attention |  | -0.051209 |  | 2026-08-01 | 2026-10-15T09:13:13.847Z | ABS (monthly CPI Trimmed Mean) |
| au-10y | What Australia pays to borrow for 10 years | RBA F2: 10y | 5.404 | % | Needs attention | 0.06 | 0.213 | 0.999204 | 2026-10-07 | 2026-10-15T09:13:13.847Z | RBA F2 (10-year bond yield) |
| rba-expectations | What markets expect from the RBA | 3-year gap | 0.333 | pts | Normal | 0.011 | -0.096 | 0.640781 | 2026-10-07 | 2026-10-15T09:13:13.847Z | RBA F2 (FCMYGBAG3D) − RBA F1 |
| au-us-10y-gap | The gap between Australian and US 10-year borrowing |  | 0.124 | pts | Normal | 0.07 | -0.261 | 0.561187 | 2026-10-07 | 2026-10-15T09:13:13.847Z | RBA F2 − FRED (DGS10) |
| au-petrol-yoy | Petrol prices vs a year ago | CPI: fuel | 13.528998 | % | Context |  | 13.883428 | 0.736842 | 2026-08-01 | 2026-10-15T09:13:13.847Z | ABS (CPI Automotive fuel) |
| rba-cash-rate | Australia’s official interest rate |  | 4.6 | % | Context | 0 | 0.25 | 0.996046 | 2026-10-14 | 2026-10-15T09:13:13.847Z | RBA F1 (Cash Rate Target) |
| au-home-loan | The home-loan rate people actually pay |  | 6.2 | % | Needs attention |  | 0 | 0.952941 | 2026-08-31 | 2026-10-15T09:13:13.847Z | RBA F6 (owner-occupier outstanding) |
| au-deposit-rate | Savings rates (new term deposits) | RBA F4.1 | 4.8 | % | Context |  | 0 | 0.988235 | 2026-08-31 | 2026-10-15T09:13:13.847Z | RBA F4.1 (new term deposits) |
| au-wage-growth | Wage growth vs a year ago |  | 3.203075 | % | Needs attention |  | -0.018575 | 0.621622 | 2026-04-01 | 2026-10-15T09:13:13.847Z | ABS (Wage Price Index) |
| au-rent-yoy | Rent growth vs a year ago | CPI: rents | 3.57823 | % | Normal |  | -0.001818 | 0.081081 | 2026-08-01 | 2026-10-15T09:13:13.847Z | ABS (CPI Rents) |
| au-unemployment | The share of Australians without work |  | 4.718349 | % | Needs attention |  | 0.066741 | 0.508475 | 2026-09-01 | 2026-10-15T09:13:13.847Z | ABS (Labour Force) |
| au-home-values | Australian home prices |  | 1100.4 | index | Normal |  | -0.739672 | 0.567568 | 2026-04-01 | 2026-10-15T09:13:13.847Z | ABS (RES_DWELL_ST) |
| au-household-debt-arrears | Australian household debt versus income |  | 178.4 | % | Normal |  | 1.2 | 0.157895 | 2026-06-30 | 2026-10-15T09:13:13.847Z | RBA E2 (household ratios) |
| audusd | Australian dollar vs US dollar | AUD/USD | 0.700967 | US$ | Normal | 0.841161 | -1.682322 | 0.500587 | 2026-10-14 | 2026-10-15T09:13:13.847Z | Frankfurter (ECB) |
| audjpy | Australian dollar vs yen | AUD/JPY | 111.068274 | ¥ | Normal | 0.981368 | 0.798681 | 0.950724 | 2026-10-14 | 2026-10-15T09:13:13.847Z | Frankfurter (ECB) |
| terms-of-trade | Australia’s export prices vs import prices |  | 94.8 | index | Normal |  | -1.5 | 0.432432 | 2026-04-01 | 2026-10-15T09:13:13.847Z | ABS (ANA_AGG terms of trade) |
| iron-ore | Iron ore price |  | 97.7 | US$ | Context |  | 1.45379 | 0.415254 | 2026-09-01 | 2026-10-15T09:13:13.847Z | World Bank Pink Sheet |
| gold-aud | Gold price in Australian dollars | gold in A$ | 5979.8792 | A$ | Context |  |  |  | 2026-10-15 | 2026-10-15T22:13:17.973Z | Yahoo Finance (gold, live) × Frankfurter (AUD) |

## Next up

| ID | Indicator | Date |
| --- | --- | --- |
| us-cpi | US consumer price index: September 2026 | 2026-10-14 |
| abs-jobs | ABS jobs report (Labour Force): September 2026 | 2026-10-15 |
| abs-cpi | ABS monthly CPI: September 2026 | 2026-10-28 |
| fed | US Fed interest rate decision (FOMC) | 2026-10-28 |
| ecb | ECB interest rate decision | 2026-10-29 |
| rba | RBA cash rate decision | 2026-11-03 |
| us-jobs | US jobs report (Employment Situation): October 2026 | 2026-11-06 |
| us-cpi | US consumer price index: October 2026 | 2026-11-10 |
| abs-jobs | ABS jobs report (Labour Force): October 2026 | 2026-11-19 |
| abs-cpi | ABS monthly CPI: October 2026 | 2026-11-25 |
| us-jobs | US jobs report (Employment Situation): November 2026 | 2026-12-04 |
| rba | RBA cash rate decision | 2026-12-08 |
| fed | US Fed interest rate decision (FOMC) | 2026-12-09 |
| us-cpi | US consumer price index: November 2026 | 2026-12-10 |
| abs-jobs | ABS jobs report (Labour Force): November 2026 | 2026-12-17 |
| abs-cpi | ABS monthly CPI: December 2026 | 2027-01-27 |
| fed | US Fed interest rate decision (FOMC) | 2027-01-27 |
| rba | RBA cash rate decision | 2027-02-09 |
| abs-cpi | ABS monthly CPI: January 2027 | 2027-02-24 |
| fed | US Fed interest rate decision (FOMC) | 2027-03-17 |
| rba | RBA cash rate decision | 2027-03-23 |
| fed | US Fed interest rate decision (FOMC) | 2027-04-28 |
| rba | RBA cash rate decision | 2027-05-04 |

## Changed this week

| ID | Indicator | Status | As of |
| --- | --- | --- | --- |
| breakeven-5y5y | Expected US inflation, five to ten years ahead | Needs attention → Normal | 2026-10-09 |
