# Asset catalog

## `sydney-harbour-opera-house-faded.png`

- **Purpose:** Decorative header background for the Australia card only.
- **Treatment:** Pale blue-gray, desaturated, soft contrast; the existing UI should apply a light gradient/fade behind text.
- **Placement:** Wide top band/header of the Australia card, with the Opera House toward the visual center/right where possible.
- **Accessibility:** Decorative background; hide it from assistive technology.
- **Important:** Never let text, status badges, flags, or controls become hard to read. Reduce/disable the artwork on narrow cards if needed.
- **Provenance:** Cropped and softened from the provided generated visual-reference board for this handoff. It is illustrative art, not a licensed photograph and not data. If it looks soft at production resolution, recreate a cleaner local equivalent using the project's approved asset workflow.

## `global-map-faded-reference.png`

- **Purpose:** Optional, very subtle background texture behind the Global card header.
- **Treatment:** Low contrast only; it must be less prominent than the region title and status badge.
- **Accessibility:** Decorative, not meaningful content; hide it from assistive technology.
- **Provenance:** Cropped and softened from the provided generated visual-reference board. It is a reference texture, not a data visualization.

## Icon guidance

Use the project's current icon library and country flag/globe assets wherever available. Prefer a consistent outline style around 18–22 px for metric/category icons. Do not crop icons out of screenshots for production use, do not use emoji as a substitute when proper icons are already available, and do not mirror non-directional icons in RTL.
