# Agent Kickoff — Implement, Verify, Commit, Push, and Deploy Currena Economic Indicators UI

Repository: **https://github.com/assadigit/Currena**

You are the implementation agent for the approved Economic Indicators UI redesign. I will provide GitHub credentials/authentication myself; never ask me to paste credentials into source code, markdown, logs, or commits.

## Mandatory first steps

1. Access the repository using the authentication method I provide.
2. Find and read the full `spec/economic-indicators-ui-spec.md` in this handoff package. If the package is attached rather than already in the repo, extract it into a temporary working directory and read it in full. Do not guess from screenshots or this prompt alone.
3. Read `README.md`, `assets/ASSET-CATALOG.md`, `spec/design-tokens.css`, and `spec/design-tokens.json`.
4. Inspect all reference images, especially `references/01-approved-dashboard-reference.png`, plus the desktop/mobile style boards.
5. Before editing, inspect the repository instructions, current branch, `git status`, recent commits, remote branch state, deployment configuration/workflows, and the actual target page/components/data/localization files.
6. Determine the real test/build/deploy commands and current deployment target from repository files. Do not invent hosting providers, secrets, deployment commands, or routes.

If the spec or required assets cannot be found/read, stop before implementation and tell me exactly what is missing.

## Design intent

Implement the approved editorial-financial direction: off-white backgrounds, strong navy typography, restrained red/amber/green severity cues, light borders, calm spacing, refined outline icons, and a subtle Sydney Harbour/Opera House background on Australia’s header. Optionally use the low-contrast world-map texture in the Global header. The UI must remain professional, readable, and not over-decorated.

On desktop, Australia is on the left and Global is on the right. On mobile, show Global first and use a horizontal swipe carousel to reach Australia. Show the top three existing flagged indicators by default, with inline expansion for the rest.

Implement actual components using the existing application architecture. The screenshots are visual references only—not web-page images and not sources for financial values or copy.

## Preserve behavior

- Do not change calculations, severity thresholds, data classification, ranking, sources, API contracts, or existing translated copy unless there is a confirmed bug and the change is necessary and documented.
- Do not hardcode numbers, mock data, screenshot copy, or placeholder values.
- Preserve the existing framework, routing, localization, state management, data fetching, caching, tools, data download/export behavior, tooltips, and other working controls.
- Scope edits to the Economic Indicators page and directly required components/assets.
- Use existing font and icon conventions where suitable; avoid new dependencies unless truly necessary.
- Implement true RTL for Persian and true LTR for English. Headings, icons, badges, arrows, labels, row flow, popovers, and keyboard behavior must all be checked—not just text alignment.
- Use the supplied Sydney and world-map files from local project assets, or recreate a cleaner local equivalent if the supplied reference crop is not production-quality. Do not hotlink assets.

## Critical warning: parallel agents are active

**Several AI agents may be working in parallel on this repository, including agents that are already committing, pushing, or deploying. Treat the shared GitHub repository and deployment target as concurrently modified.**

Before every high-impact Git action or deployment:

1. Check `git status`, current branch, recent local commits, `git fetch`/remote status as appropriate, and the latest remote commits.
2. Check whether the current working tree has changes from another agent or human. Do not overwrite, discard, reset, stash without understanding ownership, or cherry-pick blindly.
3. Check recent repository activity and the deployment workflow/status to determine if another agent is currently pushing or deploying.
4. If work is happening concurrently, coordinate/serialize the operation where a team/agent communication mechanism exists. Do not launch a competing deployment or push over a moving target.
5. Use a dedicated, descriptively named feature branch if the repository conventions permit; do not work directly on a shared deployment branch by default.
6. Never force-push, rewrite shared history, delete someone else's branch, revert another agent's changes, or run destructive cleanup commands.
7. Before integration, fetch the latest remote state and reconcile conflicts conservatively. Preserve others' commits. If resolving a conflict risks another agent's work, stop and report the precise blocker rather than guessing.
8. If a production deployment is already in progress, wait for it to settle and verify its result before triggering a new one. If there is no safe way to coordinate the deployment queue, commit and push your feature branch, but pause before production deployment and report why; do not create a deployment race.

Do not interpret “complete the task” as permission to overwrite parallel work. Successful, conflict-free delivery is more important than being first to push.

## Implementation workflow

### Phase 1 — Baseline and plan

- Identify the page entry point, component tree, CSS/theme conventions, icon/font setup, data source, translations, and existing test tooling.
- Run the app/tests before edits when possible and capture the baseline.
- Briefly record the implementation plan and list the files likely to change.

### Phase 2 — Implement

- Follow the complete spec's layout, visual tokens, typography, assets, category summary, three-item initial list, and interactions.
- Implement the mobile Global-first horizontal carousel with swipe/scroll-snap and accessible previous/next controls; do not stack the cards vertically on mobile.
- Keep card ordering stable on desktop (Australia left, Global right) while inner layout follows locale direction.
- Use real application data and existing translation infrastructure. Keep presentation mappings separate from financial logic.
- Do not change unrelated pages or perform broad refactors.

### Phase 3 — Verify

Run the project's appropriate lint, type-check, tests, and production build, based on actual package scripts/configuration. Test as much as the environment supports:

- Desktop at approximately 1280–1440 px.
- Tablet around 768–1023 px.
- Mobile widths 320, 375, and 430 px.
- Persian RTL and English LTR.
- Global first on mobile; swipe and controls navigate to Australia and back.
- Correct RTL headings/icons/badges/arrows and mixed-script/number rendering.
- Top-three list and expand/collapse for both regions.
- Existing downloads/tools/language control/tooltips and all relevant category or error states.
- Header art contrast, crop, fallback, and no text collisions.
- No unintended page-level horizontal overflow; only the intended carousel track may scroll horizontally.
- No new browser console errors or regression in calculations/data behavior.

Do not claim a check passed unless you actually ran it. Fix all introduced failures and repeat the relevant checks.

### Phase 4 — Commit and push

After implementation and verification:

1. Review the complete diff and check for unrelated edits, generated junk, secrets, accidental data changes, or screenshot-as-UI shortcuts.
2. Re-check current branch and remote activity; fetch and reconcile safely with parallel work.
3. Create a clear commit on the feature branch with a message such as `feat(ui): redesign economic indicators page` (adjust to project conventions).
4. Push the feature branch to GitHub without force-pushing.
5. If the repository's normal workflow requires a pull request, create/update it only if the tools and credentials permit and report its URL; do not bypass branch protections.

### Phase 5 — Deploy

I am asking for a complete delivery including deployment, but only use the repository's existing, documented deployment process and only after checking for competing deployment activity. Do not make up a deployment command or deploy to an unfamiliar production target.

- Inspect workflows, deployment docs, and required environment configuration.
- Confirm current remote/integration state before triggering deployment.
- Coordinate with parallel agents; do not trigger overlapping deployments.
- Deploy only the intended verified commit through the established pipeline. If production deployment requires approval, a protected action, unavailable secret, or a coordination decision I must make, finish all safe steps and ask for the specific authorization/blocker instead of bypassing protection.
- After deployment, verify the resulting workflow/job status and smoke-test the live page if a known deployment URL is available from repository configuration. Do not claim deployment success from a successful build alone.

## Definition of done

- Specification implemented for this page.
- Correct visual treatment, assets, and responsive behavior.
- Correct RTL/LTR rendering and mobile Global-first carousel.
- Existing data and functionality preserved.
- Relevant automated checks run and regressions fixed.
- Changes committed and pushed on a safe branch.
- Deployment completed through the established process only when safe and authorized, with deployment status verified.
- Final report distinguishes what was implemented, tested, committed, pushed, and deployed.

## Final report required

Provide:

1. Summary of the UI changes.
2. Files changed/added.
3. RTL/LTR and responsive viewports tested.
4. Exact test/lint/build commands run and outcomes.
5. Commit hash and branch; push result.
6. Deployment method/status and verification, or the exact reason deployment was paused.
7. Any remaining issue or acceptance criterion that is not met.
8. How you avoided conflicts with other agents' commits/deployments.

Be factual, do not fabricate passing tests, and do not mark work as deployed unless the deployment itself completed successfully.
