# Currena — World Market Indices Redesign Handoff

This package contains the implementation brief and visual direction for redesigning the World Market Indices area on Currena's Insights page.

## Contents

- `01-new-session-prompt.md` — paste into a fresh coding-agent session after opening the repository.
- `02-ui-spec.md` — product, information architecture, layout, content, responsive behavior, visual tokens, and acceptance criteria.
- `03-agent-rules.md` — task-specific rules that supplement, never replace, the repository's root `AGENTS.md`.
- `04-visual-style-reference.png` — generated visual direction for desktop and mobile. It is an aesthetic reference, not an exact or data-accurate production mockup.
- `ASSET-MAP.md` — logo filenames mapped to index names and markets.
- `assets/index-logos/` — the 16 provided 256 × 256 index/market logo assets.

## Project context already verified

The public repository README describes Currena as a TypeScript monorepo with a Hono API on Cloudflare Workers and a Vite + React SPA. Its root `AGENTS.md` further identifies `apps/web` as a Vite/React/TypeScript/Tailwind PWA, `apps/api` as the API Worker, `apps/markets` as the scheduled market-data pipeline, and `packages/core` as the home for shared Zod contracts. It also sets mandatory localization, RTL/LTR, formatting, testing, and phase-discipline requirements.

**Important:** The agent must inspect the checked-out repository and its current specs before implementing. This handoff does not override the current source tree, runtime contracts, `AGENTS.md`, hard gates, or data truth.

## Suggested use

1. Open the current repository: https://github.com/assadigit/Currena
2. Start a new coding-agent session with `01-new-session-prompt.md`.
3. Give the agent this whole folder or ZIP so it can read the UI spec, agent rules, style reference, and source logos.
4. Keep the visual reference nearby while reviewing the implementation, but use the written spec and actual data contracts as the source of truth.

## Key product decision

The section describes **stock-market indices**, not stock exchanges. The preferred editorial heading is **نبض بازارهای جهان**, with **شاخص‌های بورسی جهان** as the explicit descriptive label. Use index names, market/country labels, percentage returns, and last-close context consistently.

## Source links

- Repository README: https://github.com/assadigit/Currena/blob/main/README.md
- Root agent handbook: https://github.com/assadigit/Currena/blob/main/AGENTS.md
