# UI specification — World Market Indices / Insights

**Product:** Currena  
**Page:** Existing Insights page (`/#/insights`)  
**Primary locale:** Persian (fa-IR), RTL; preserve all supported locales  
**Audience:** Everyday users who want a fast, trustworthy view of global stock-market index performance  
**Data cadence:** End-of-day / last available market close; no intraday real-time promise  
**Design concept:** Editorial Market Brief + Market Movers + Regional Explorer; optional desktop heatmap

---

## 1. Product intent

The page should answer, in this order:

1. What has been happening across the covered world indices?
2. Which indices rose or fell the most over the selected period?
3. How do the individual markets compare by region?
4. Is an index close to its 52-week high, in a pullback/correction, or materially below its high?
5. How has performance differed across the short and longer time horizons?

The experience is a market briefing, not a trader's terminal. Prioritize comprehension, trustworthy provenance, and effortless comparison over dense decoration.

### Naming discipline

- Editorial title: **نبض بازارهای جهان**
- Descriptive section label: **شاخص‌های بورسی جهان**
- Refer to the covered measures as **indices / شاخص‌ها**.
- Use **stock exchange / بورس** only when referring to an actual exchange operator or venue.
- Do not use “markets” and “indices” interchangeably when that could mislead users.

## 2. User and content priorities

### Primary user
A general Persian-speaking visitor who does not necessarily understand exchange/index terminology and wants a short daily briefing with optional deeper comparison.

### Priorities
1. Readability and clear interpretation of signed percentage returns.
2. Country/market identification plus canonical index name.
3. Selected period is always obvious.
4. Region-based scan of all covered indices.
5. Last-close date and data freshness are visible.
6. 52-week-high distance gives longer-context information without masquerading as a return.

## 3. Page information architecture

### 3.1 Header and provenance

**Heading:** `نبض بازارهای جهان`  
**Descriptor:** `عملکرد شاخص‌های بورسی منتخب تا پایان آخرین جلسه معاملاتی`

Show:
- Last available date/time label based on the actual snapshot metadata.
- `آخرین داده‌ها · پایان جلسه معاملاتی` or equivalent existing localized wording.
- A clear stale-data indication if the snapshot is older than expected.

Do not imply that all global indices close simultaneously. Use “last available close” / “end-of-day data” as appropriate. Never use “live” or “real time” for this snapshot.

### 3.2 Market breadth summary

A compact, calm summary card with the count of covered indices that rose, fell, or were flat **over the selected period**. The selected period must be visible in the card or label.

Recommended Persian labels:
- `شاخص‌های مثبت`
- `شاخص‌های منفی`
- `بدون تغییر` (only if a real neutral definition/data state exists)

Include a separate secondary context line where data exists, e.g. `۴ شاخص بیش از ۱۰٪ پایین‌تر از سقف ۵۲هفته‌ای هستند`.

Do not use an abstract word such as `مختلط` as the only summary. A descriptive headline may be added only when it follows explicit, tested data rules. Use unrounded values for counts and thresholds, then round only for display. If a displayed distance rounds to 10% while the exact value is below 10%, do not count it as at least 10% below the high.

Correction status and bear-market status must follow the current data contract/domain rule. If current rules define correction as at least 10% below a 52-week high and bear market as at least 20%, preserve those exact thresholds; do not create a competing frontend definition.

### 3.3 Period selector

Target horizons:
- `روزانه` — daily close-to-close return
- `هفتگی` — weekly return
- `ماهانه` — monthly return
- `سه‌ماهه` — quarterly / three-month return
- Annual return, labeled according to its true definition:
  - `۱۲ماهه` for a rolling 12-month return, or
  - `از ابتدای سال` for calendar year-to-date performance.

Never present year-to-date as trailing 12 months or vice versa. Inspect the existing response, schema, and calculation before choosing the label. If a requested horizon is not actually present and cannot be safely computed from a trusted existing history series, do not fabricate it; surface the data gap in the implementation report.

The **distance from the 52-week high is not a return period**. Present it as a secondary metric, status, or independent table column, not as a fifth/sixth return tab.

Interaction behavior:
- Period changes update breadth counts, top movers, the explorer's return values, the heatmap, and accessible labels together.
- Preserve the selection while the user expands rows or switches list/heatmap view.
- Provide an unambiguous active state, keyboard operation, and screen-reader label.
- If the existing page already has a filter pattern, reuse it rather than creating a parallel state model.

### 3.4 Market movers

Two featured cards:
- `بیشترین رشد`
- `بیشترین افت`

Each card contains:
- Supplied index logo (within a consistent logo frame).
- Canonical index name.
- Country/market name; flag may supplement but never replace the written name.
- Selected-period signed return with a clear positive/negative sign and directional cue.
- Distance to 52-week high or related status as secondary context, only when available.
- Small explanatory period label if ambiguity is possible.

These cards are ranked from the actual selected-period dataset and update when the period changes. Omit or explicitly handle missing returns; never rank missing values as zero. If there are no valid values, show a useful empty state rather than a fake winner.

### 3.5 Regional index explorer

Regions and counts:
- **آسیا و اقیانوسیه (۷)**
- **اروپا (۴)**
- **آمریکا (۵)**

Use counts only if the current supported data contains exactly these 16 indices; calculate them from the loaded dataset where appropriate.

Each index row/card displays:
- Logo in a standardized frame, preserving aspect ratio via `object-fit: contain`.
- Canonical index name as primary text.
- Country or market as secondary text.
- Selected-period return as the most visually prominent metric in the row.
- Distance to 52-week high / pullback context as quieter secondary text if available.
- Optional sparkline only if a trusted historical close series already exists and the chart adds meaning.
- Expand/click affordance only if there is useful detail to reveal; avoid inert cards that look interactive.

Use region headings to create a rhythm and reduce the sense of a flat catalogue. On desktop, region sections can be grouped into the wider explorer; on mobile, use compact sections that are easy to scan and optionally collapsible.

### 3.6 Heatmap / alternate visualization

Provide an optional desktop view switch such as `فهرست` / `نقشه عملکرد` only if it integrates naturally with the existing component architecture.

Heatmap rules:
- Each tile represents one named index.
- **Tile area is equal across indices** unless the source supplies a defensible, comparable weighting metric and the UI labels that meaning. Do not enlarge an index just because its return is larger.
- Color encodes the selected period's return; every tile also shows its name/abbreviation and exact signed percentage.
- Use a visible legend centered around zero. Explain that intensity is relative to the currently selected period if the scale is dynamically normalized.
- Color is never the only indicator: show plus/minus signs and labels/icons, and expose equivalent content in the index list/table.
- Tooltips may provide full index name, country/market, return and selected period, but hover is supplementary; mobile and keyboard users must have an equivalent tap/focus experience.
- The heatmap is secondary to precise comparisons, not a replacement for the ranked list.

On mobile, default to the readable list. If heatmap is offered, use a simplified, labelled grid without tiny unreadable tiles or hover-only information.

### 3.7 Detailed comparison table

On desktop, consider a full table or compact comparison row when it improves exact comparison. Suggested columns:
- Region / index (logo + canonical name)
- Country/market
- Selected-period return
- Distance to 52-week high
- Optional trend sparkline if data exists

The table should support the same period state as cards and heatmap. Follow existing repository patterns for sorting, table semantics, and responsive overflow.

## 4. The 16 supplied index assets and labels

Use `ASSET-MAP.md` as the filename-to-index mapping. Market identity must be textual as well as visual. The prepared images are logo assets; the source may represent a publisher/exchange brand rather than an index-specific mark. Never let a logo override the canonical name in data.

| Region | Display name | Market/country label |
|---|---|---|
| Asia-Pacific | Nikkei 225 | Japan / ژاپن |
| Asia-Pacific | S&P/ASX 200 | Australia / استرالیا |
| Asia-Pacific | KOSPI | South Korea / کره جنوبی |
| Asia-Pacific | Hang Seng Index | Hong Kong / هنگ‌کنگ |
| Asia-Pacific | Shanghai Composite | China / چین |
| Asia-Pacific | TAIEX | Taiwan / تایوان |
| Asia-Pacific | Nifty 50 | India / هند |
| Europe | EURO STOXX 50 | Eurozone / منطقه یورو |
| Europe | DAX | Germany / آلمان |
| Europe | CAC 40 | France / فرانسه |
| Europe | FTSE 100 | United Kingdom / بریتانیا |
| Americas | S&P 500 | United States / آمریکا |
| Americas | Nasdaq-100 | United States / آمریکا |
| Americas | Dow Jones Industrial Average | United States / آمریکا |
| Americas | S&P/TSX Composite Index | Canada / کانادا |
| Americas | Ibovespa | Brazil / برزیل |

If a canonical source identifier differs, preserve it in data and use a well-defined presentation label. Do not silently change data identifiers to match a logo filename.

## 5. Responsive behavior

### Desktop: >= 1200 px

- Center content with a comfortable maximum width; use the actual app container conventions.
- Establish a clean editorial hierarchy: header/provenance, summary and market breadth, two featured movers, then the explorer.
- The desktop layout can show an optional equal-area heatmap alongside or above the regional list/table.
- Use available horizontal space for comparisons, not oversized decorative illustrations.
- Keep index name, country, return, and high-distance readable at normal zoom.

### Tablet: 768–1199 px

- Collapse multi-column modules gracefully.
- Featured movers may remain two-up if each has adequate width; otherwise stack.
- Avoid horizontal overflow; allow region sections to wrap.
- Keep the table usable via existing responsive patterns, or switch to readable rows/cards rather than scale type down excessively.

### Mobile: < 768 px

- Design as a deliberate single-column reading experience, not a shrunken desktop dashboard.
- Suggested order: title/date → market breadth → compact gainer/loser cards → period selector → regional index list.
- Period options may scroll horizontally only if the active choice remains obvious and the control is keyboard-accessible; avoid clipping labels or relying on tiny type.
- Index row: 24–32 px logo, short canonical name, country/market, selected-period return, and a quiet secondary line for 52-week-high distance.
- Put additional horizons, status definitions, and sparkline/detail content inside an explicit expansion surface if needed.
- If a mobile heatmap is kept, it must be large enough to tap, show labels/value, and have a non-visual alternative; otherwise leave heatmap as desktop-only.
- Minimum comfortable touch targets should follow the app's established accessibility baseline; aim for about 44 × 44 CSS px where feasible.
- Avoid hover-only controls and avoid horizontal page scrolling.

## 6. Visual system and tokens

Use this as the task-level visual target, but reuse any existing Currena tokens where a similar token already exists. Do not establish a second unrelated design system.

| Token | Target | Purpose |
|---|---|---|
| Page background | `#F4F8FB` | Calm cool neutral canvas |
| Surface | `#FFFFFF` | Cards and table surfaces |
| Main ink | `#173B5B` | Strong Persian/Latin headings |
| Body ink | `#29465F` | Main text |
| Muted text | `#60758A` | Metadata / secondary labels |
| Borders | `#D9E5EC` | Light separators and card edges |
| Primary accent | `#1764A0` | Controls and selected navigation |
| Positive | `#11845B` | Gains, with sign and/or arrow |
| Positive soft | `#E7F6EF` | Tinted positive surface |
| Negative | `#D94850` | Losses, with sign and/or arrow |
| Negative soft | `#FFF0F1` | Tinted negative surface |
| Warning | `#B86E14` | Stale data / caution only when semantically needed |
| Neutral movement | `#6B7B8C` | Flat / no meaningful move |

Style guidance:
- Bright, editorial light theme; restrained use of color.
- White surfaces, subtle borders, small soft shadows, and consistent 12–16 px corner radius for normal cards. Larger editorial panels may have a little more radius if existing components support it.
- Use a spacing rhythm based on 4/8 px increments and the application's current spacing tokens.
- Use existing font stack and Persian font assets. Do not import a new font unless needed and approved.
- Respect RTL naturally and use CSS logical properties (`ms/me/ps/pe`, etc.).
- Signed percentage is the key numeric visual: use stable/tabular numerals if current typography supports them; format only at render time with existing locale utilities.
- Preserve Latin index names/tickers legibly inside RTL rows; use appropriate bidi isolation/`dir="ltr"` at the text-run level where necessary.
- Do not use a large gauge, oversized coin illustration, or decorative world map at the expense of useful data.
- Do not rely on color alone and test text/background contrast.

## 7. UX writing examples

Use the existing terminology dictionary as the final authority and submit all Persian copy changes through the repository's copy-audit workflow. These are directionally preferred phrases, not permission to hardcode literal strings outside i18n.

| Purpose | Preferred direction |
|---|---|
| Editorial title | `نبض بازارهای جهان` |
| Descriptive title | `شاخص‌های بورسی جهان` |
| Last close | `آخرین داده‌ها · پایان جلسه معاملاتی` |
| Best positive mover | `بیشترین رشد` |
| Worst negative mover | `بیشترین افت` |
| Selected timeframe | `عملکرد در بازه انتخاب‌شده` |
| 52-week-high distance | `فاصله تا سقف ۵۲هفته‌ای` |
| Below-high count | `شاخص بیش از ۱۰٪ پایین‌تر از سقف ۵۲هفته‌ای` |
| Missing history | `اطلاعات این بازه در دسترس نیست` (localized and aligned with product tone) |

Avoid unsupported editorial claims such as “investors are panicking” or causal explanations that are not provided by a trusted source. Prefer factual summaries such as `۱۲ شاخص از ۱۶ شاخص در این بازه افت کرده‌اند`, with counts calculated from the selected period.

## 8. Data, computation, and states

- Source-of-truth for each value is the current typed API response/snapshot; inspect before coding.
- User-facing percentage returns use the period's canonical return field, never string parsing or derived values from rounded labels.
- 52-week-high distance remains a separate field/metric.
- Calculate up/down/flat counts and top movers from raw numeric values.
- The “10% below high” count must use the raw distance value, not rounded text.
- If a selected horizon is missing for a market, don't treat it as 0%. Handle partial data intentionally and show coverage/missing state if it materially affects the summary.
- The summary denominator should be the number of indices with valid data for that measure, and the UI should not imply all 16 values are available if they're not.
- Do not call market-data providers from the SPA or page request. Keep the scheduled-data design intact.
- Display a truthful “last updated” or “last close” timestamp from metadata. Use existing locale/timezone helpers and avoid implying all regions share one closing time.

### Required UI states

- Loading: lightweight skeletons that preserve layout; don't display placeholder percentages as if real.
- Success: data and timestamp visible.
- Partial data: display available indices; explain missing data and calculate denominators honestly.
- Stale snapshot: a restrained warning/metadata label, according to existing freshness rules.
- API error: useful localized message and retry behavior only if existing request handling supports it.
- Empty: clear explanation; never fabricate a fallback market summary.

## 9. Accessibility and interaction

- Keyboard-accessible period control and list/heatmap switch.
- Visible focus indicators using existing tokens.
- Semantic headings in meaningful order.
- Every icon-only button has a localized accessible name.
- Chart/heatmap values are also available in textual list/table form.
- Up/down arrows and plus/minus signs complement red/green; never use color alone.
- Screen readers should hear full index names, country/market, selected period, value, and whether the value is missing.
- The heatmap uses keyboard focus and tap for details; hover tooltip is supplementary.
- Respect reduced-motion preferences if any animation is introduced.

## 10. Non-goals / out of scope

- No new market-data vendor or provider integration in this UI task.
- No intraday/live-data promise.
- No investment recommendations or predictive claims.
- No change to market snapshot cadence, cron schedule, storage, authentication, or production deployment.
- No redesign of the entire Currena app or currency-converter flow.
- No treemap tile area based on return magnitude or made-up market-cap weights.
- No copy/paste of generated image text or illustrative data into production.

## 11. Acceptance checklist

- [ ] The current `/#/insights` route remains functional and integrated with the existing app shell/navigation.
- [ ] The page correctly calls the data **indices**, not exchanges.
- [ ] Every displayed index is named and has a country/market label; logos are supplementary identifiers.
- [ ] All 16 intended index labels map correctly to existing data IDs and the supplied assets, or discrepancies are documented.
- [ ] Current period is explicit and controls all relevant values and counts.
- [ ] Daily, weekly, monthly, quarterly and annual/year-to-date horizons are implemented only where actual source data supports them, with correct annual semantics.
- [ ] 52-week-high distance is separate from return periods; threshold counts use raw values.
- [ ] Top movers are true extrema of the selected-period data; absent/partial data is handled honestly.
- [ ] Desktop heatmap (if present) uses equal-area tiles unless a real weighting metric is explicitly available, includes a legend, and has a textual alternative.
- [ ] Mobile layout is readable at 320–390 px widths, has no accidental horizontal page overflow, and does not depend on hover.
- [ ] Persian copy is routed through i18n and the copy-audit workflow is updated/passing.
- [ ] Typecheck, lint, tests, copy audit and web build pass, or exact blockers are reported.
- [ ] No provider integration, API/schema changes, cron modifications, legacy-app edits, deployment, or hard-gate crossings occur without appropriate human approval.
