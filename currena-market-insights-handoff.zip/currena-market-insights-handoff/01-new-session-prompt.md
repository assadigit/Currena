# New-session prompt — Currena World Market Indices redesign

Paste the following prompt into a new coding-agent session, and attach/provide this handoff folder (especially `02-ui-spec.md`, `03-agent-rules.md`, `04-visual-style-reference.png`, and `assets/index-logos/`).

---

You are working in the existing repository: https://github.com/assadigit/Currena

Implement the redesign of the world stock-market indices area on the current Insights page (`/#/insights` in the deployed experience). The objective is to make the page feel like a polished financial-editorial market briefing for ordinary Persian-speaking users, while retaining a rigorous, usable comparison tool for desktop and mobile.

## Read first — do not skip

1. Root `AGENTS.md` and `README.md`.
2. `docs/PROGRESS.md`, `docs/REMAINING_WORK.md`, `docs/FEATURE_MAP.md`, and `docs/MIGRATION_CHECKLIST.md`.
3. `docs/specs/traceability.md` and the current governing spec(s) that cover Insights, market snapshots, or the market data API.
4. `docs/localization/persian-copy-workflow.md`, `docs/localization/persian-terminology.md`, and the current Persian copy manifest / audit workflow.
5. Current Insights route and components in `apps/web`, the relevant API route(s) in `apps/api`, the scheduled snapshot implementation in `apps/markets`, and shared schemas in `packages/core`.
6. Existing tests, component patterns, design tokens, responsive conventions, icon/logo handling, and available date/number formatting utilities.

The repository handbook describes a pnpm TypeScript monorepo: React + Vite + Tailwind PWA in `apps/web`, Hono API on Cloudflare Workers in `apps/api`, scheduled-only market ingestion/snapshots in `apps/markets`, and shared Zod contracts in `packages/core`. Treat the checked-out source as authoritative and verify all paths/contracts before editing.

## Product goal

Build an editorial market briefing with:

- A clear header: `نبض بازارهای جهان`, with `شاخص‌های بورسی جهان` as the descriptive label.
- Last available end-of-day / market-close context, including a truthful timestamp/date and a clear stale-data state if relevant.
- An evidence-based market breadth summary: number of indices up/down/flat over the selected period, plus a separate count of indices at least 10% below their 52-week high when raw data supports it.
- Two featured, data-driven market movers: biggest gainer and biggest decliner for the selected period.
- A period control for daily, weekly, monthly, quarterly, and annual performance, but only show a period when its value and semantics are supported by the real data contract. Distinguish rolling 12-month return from calendar-year-to-date; never label one as the other.
- An easy-to-scan regional index explorer for Asia-Pacific, Europe, and the Americas, showing each index's logo, canonical index name, country/market, selected-period return, and 52-week-high distance as secondary context.
- A desktop-first optional performance heatmap / bento view. Tile size must not imply market capitalization or importance unless the data explicitly supplies a comparable size metric. Exact numbers and a non-color-only alternative must remain available.
- A deliberate mobile layout, not a compressed desktop grid.

## Use these task artifacts

- `02-ui-spec.md` is the functional and visual source of truth for this task.
- `03-agent-rules.md` supplements the root `AGENTS.md` and contains task-specific implementation constraints.
- `04-visual-style-reference.png` is visual inspiration only. Its generated copy, percentages, flags, logos, and market details are not data sources and must not be copied into the product.
- `ASSET-MAP.md` maps the provided logo files to the known 16-index universe. Copy only the needed assets into the repository's existing asset convention; do not leave unused duplicates.

## Data truth and scope boundaries

The user wants daily, weekly, monthly, quarterly, and annual performance based on end-of-day data. They also supplied a distance-to-52-week-high measure; this is a separate contextual metric, not a return period.

Before implementation, verify precisely which horizons exist in the current API response, shared schema, and scheduled snapshot. Do not fabricate values or silently substitute distance from a 52-week high for annual return. If an expected horizon is absent, use only truthful supported values and report the exact schema/data gap. Do not expand or replace market providers, ingestion, cron schedules, storage, or API contracts without first stating the required change and obtaining explicit human approval.

Market calculations, freshness, correction/bear-market flags, and top movers must be derived from trusted raw values, not rounded UI strings. Do not call data providers from a page request. Do not create a second set of frontend-only contracts if a shared Zod contract already exists.

Use the exact market universe and labels in `ASSET-MAP.md`, adjusting a name only if the existing data source provides an authoritative canonical name. The current brief is about indices, not exchanges.

## Design direction

Follow the hybrid recommendation in `02-ui-spec.md`: editorial market summary + prominent gainers/losers + regional index explorer, with a desktop heatmap as an alternate visualization. Use restrained blue/navy neutrals, white surfaces, subtle borders, readable typography, green/red movement cues, and clear hierarchy. Keep precise values readable and avoid decorative gauges that do not answer a user question.

Persian is RTL. Respect other existing locales and use current i18n dictionaries. Never hardcode user-facing Persian labels in components when the repository's localization conventions require dictionary entries.

## Execution protocol

1. Report a short baseline: current route/components/data fields, existing reusable UI, and actual supported return horizons. Note any mismatch between the 16-index display labels and source identifiers.
2. Follow the phase/gate discipline in `AGENTS.md` and `docs/PROGRESS.md`. Do not cross an explicit human-approval gate.
3. Implement the smallest complete slice that meets the UI spec; reuse existing components and tokens, avoid dependencies unless justified.
4. Keep data fetching/API boundaries as they are. Correctly represent loading, error, no-data, partial-data, and stale-data states.
5. Add/adjust unit/component tests for period selection, top movers, missing fields, raw-value threshold calculations, localization, and responsive/accessibility behavior as appropriate to the existing test setup.
6. Update the copy audit manifest using the documented workflow for every changed Persian string. Run `pnpm copy:audit` and resolve its findings.
7. Run `pnpm -r typecheck`, `pnpm lint`, `pnpm -r test`, and the web build (`pnpm --filter @currena/web build`) as applicable. Never make tests call live providers.
8. Update the required progress/decision/spec traceability documents and add a phase commit only when consistent with repository workflow. Do not deploy or modify the legacy production Django app.

## Acceptance criteria

The implementation is ready for review when it meets the acceptance checklist in `02-ui-spec.md`, respects every applicable requirement in the root `AGENTS.md`, has no invented market values, behaves well at mobile and desktop widths, and reports any unsupported data horizon explicitly.

Start by inspecting, not by rewriting. Then implement within the approved scope.

---
