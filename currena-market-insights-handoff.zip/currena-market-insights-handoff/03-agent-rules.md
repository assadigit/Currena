# Task-specific agent rules — Currena World Market Indices UI

These rules supplement the repository's root `AGENTS.md`; they never replace it. If this file and the root handbook differ, obey the root handbook and stop to report a material conflict.

## A. Inspect before changing

1. Read the repo root `AGENTS.md`, current progress/gate docs, feature map, governing spec, traceability map, localization workflow, and relevant tests before editing.
2. Inspect the actual route, source components, API response, shared schemas, and snapshot writer. Paths in this handoff are architectural hints; validate them in the checked-out branch.
3. Establish a small baseline report: current page composition, current supported return fields, freshness fields, asset organization, and localization/audit impact.
4. Follow the repository's phase discipline. Never cross a hard gate without explicit human approval.

## B. Preserve architecture and data contracts

- Treat the feature as a targeted update to the existing Insights flow, not a new app or route unless repository evidence requires it.
- Reuse current components, tokens, formatters, fetch/query patterns and typed client.
- Shared Zod contracts belong in `packages/core/src/schemas.ts` according to root rules; import existing contracts instead of redefining them in frontend code.
- Keep API/provider calls and scheduled snapshot logic on their current sides of the boundary. Page requests must not contact market-data providers.
- Use snapshot/API raw values and source timestamps. Do not manufacture market prices/returns, transform missing values into zero, rank nulls as real values, or derive counts from rounded text.
- Do not add or swap data providers, modify cron cadence, expand storage/schema, adjust deployment, or edit the legacy production Django app in this UI task unless a clearly explained proposal receives explicit human approval.
- A missing annual horizon is a data-contract gap, not permission to display random/example values. Build the supported UI truthfully, report the gap, and request approval before broadening scope.

## C. Respect repository-specific UI/localization rules

- Preserve all supported locales; do not assume Persian is the only locale.
- All new/changed user-facing strings must follow the existing i18n dictionary pattern (`apps/web/src/i18n/`).
- Every changed Persian string must be handled using `docs/localization/persian-copy-workflow.md` and the Persian copy manifest. Run the documented audit, including `pnpm copy:audit`.
- Use `dir` and existing RTL/LTR helpers; CSS must use logical properties, not left/right hardcoding (`ms/me/ps/pe`, etc.).
- Internal numbers remain canonical; use existing locale formatters at render time (`fa-IR`/`en-US` or the repo's actual configured locale set). Do not store preformatted digits in state or contracts.
- Keep English index names/tickers correctly legible inside RTL layouts; use proper bidi isolation where required.
- Follow the current icon system, visual tokens, component naming, lint and file organization. Do not add a UI/graph library without justification.

## D. Index semantics and asset handling

- Use `ASSET-MAP.md` as the proposed presentation mapping, then verify it against the current market-data identifiers and exact existing display names.
- Index names are not exchange names. Keep canonical index name as the primary label; country/market is secondary; a logo is supplemental.
- EURO STOXX 50 is a eurozone index, and Hong Kong is a market label rather than a country. Keep those distinctions visible.
- Treat the supplied JPEG logo set as 256 × 256 sources. Check if the source artwork contains whitespace/background; preserve it using `object-fit: contain`, avoid stretch/crop, and use consistent frames. Follow existing public-asset and naming conventions; avoid shipping duplicated assets.
- Use an accessible text fallback or existing flag/initials treatment if the logo fails to load. Do not make a newly sourced logo dependency necessary for the page.

## E. Performance and accessibility

- Design mobile deliberately. Verify at least 320 px, 375/390 px, tablet, and desktop widths.
- Avoid horizontal page overflow, tiny clipped labels, hover-only details, and controls too small to tap.
- Heatmap values need a table/list equivalent; color cannot be the only signal. Use signed percentages and clear labels, and check contrast.
- Make loading, empty, partial, stale, and error states explicit and localized.
- Respect reduced motion and keyboard navigation. Use semantic document headings and accessible names for icon-only controls.
- Avoid placing every index into a separate heavy chart; use sparklines only if existing trusted history data makes them useful.

## F. Testing and review gates

Add or update targeted tests consistent with the existing test framework for:

- selected-period behavior and value consistency across summary, movers, heatmap, and index list;
- top-gainer/top-loser behavior with positive/negative/mixed/partial/missing data;
- 52-week-high threshold calculations using raw values, including rounding-boundary cases;
- period label semantics, especially trailing 12 months versus calendar YTD;
- locale/i18n and RTL rendering where existing test patterns permit;
- responsive layout/accessibility behavior where existing test infrastructure permits.

Use fixture-backed tests only; tests must never hit live sites/providers. Run the repository's required checks, including as applicable:

```sh
pnpm -r typecheck
pnpm lint
pnpm -r test
pnpm copy:audit
pnpm --filter @currena/web build
```

Report commands that could not be run and why. Do not claim a check passed unless it ran and passed.

## G. Documentation and communication

- Update `docs/PROGRESS.md` and applicable governing specs/traceability according to root workflow.
- Keep phase commits and message format consistent with existing repository rules; do not commit secrets or generated build outputs.
- Clearly report: changed files, design behavior, supported periods, tests run, copy-audit result, data limitations, and anything requiring human approval.
- The visual reference is non-authoritative for text and market figures; never copy its generated percentages into production.
