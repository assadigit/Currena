# Provided index-logo asset map

The archive supplied with the design conversation contains 16 JPEG files, each prepared at 256 × 256 px. The archive has been unpacked into `assets/index-logos/` for this handoff. Use the app's existing asset conventions when integrating them.

| Source filename | Preferred presentation name | Country / market | Region | Notes |
|---|---|---|---|---|
| `Japan-NIKKEI.jpg` | Nikkei 225 | Japan / ژاپن | Asia-Pacific | Index name |
| `Australia-ASX.jpg` | S&P/ASX 200 | Australia / استرالیا | Asia-Pacific | ASX filename is shorter than the index label |
| `South-Korea-KOSPI.jpg` | KOSPI | South Korea / کره جنوبی | Asia-Pacific | Index name |
| `Hongkong-HANG-SENG.jpg` | Hang Seng Index | Hong Kong / هنگ‌کنگ | Asia-Pacific | Hong Kong is a market label |
| `China-SSE.jpg` | Shanghai Composite | China / چین | Asia-Pacific | SSE identifies the exchange in the source filename; display the index |
| `Taiwan-TAIEX.jpg` | TAIEX | Taiwan / تایوان | Asia-Pacific | Index name |
| `India-Nifty50.jpg` | Nifty 50 | India / هند | Asia-Pacific | Index name |
| `Euro-STOXX.jpg` | EURO STOXX 50 | Eurozone / منطقه یورو | Europe | Regional index, not one country |
| `Germany-DAX.jpg` | DAX | Germany / آلمان | Europe | Index name |
| `France-CAC40.jpg` | CAC 40 | France / فرانسه | Europe | Index name |
| `UK-FTSE.jpg` | FTSE 100 | United Kingdom / بریتانیا | Europe | Index name |
| `USA-S&P 500.jpg` | S&P 500 | United States / آمریکا | Americas | Index name |
| `USA-Nasdaq.jpg` | Nasdaq-100 | United States / آمریکا | Americas | User's provided data explicitly names Nasdaq 100; verify source ID |
| `USA-DOW-JONES.jpg` | Dow Jones Industrial Average | United States / آمریکا | Americas | Use the canonical display name supported by source data |
| `Canada-TSX.jpg` | S&P/TSX Composite Index | Canada / کانادا | Americas | TSX filename is shorter than the index label |
| `Brazil-Bovespa.jpg` | Ibovespa | Brazil / برزیل | Americas | Common benchmark name |

## Integration rules

1. Verify the actual API/source identifiers against these labels before wiring assets.
2. Keep the index ticker/identifier separate from file name and logo.
3. In the UI, display the index name first and country/market second; a flag can supplement text but cannot replace it.
4. Preserve image aspect ratio. Use a consistent neutral frame and `object-fit: contain`, not `cover`, unless source inspection proves the artwork needs a different treatment.
5. Provide a non-broken fallback if an asset is missing; do not silently substitute an unrelated logo.
6. Do not treat the generated style-reference image as proof of logo accuracy; use these source files and the data contract.
